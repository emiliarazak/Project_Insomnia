package cell.facility.road;
import static org.junit.Assert.*;
/**
*
* @author Emil
*/
import org.junit.Test;

import indices.Indices;

public class RoadTest {
	private Indices ind = new Indices(1,4);
	private Road s = new Road(ind, 1);
	@Test
	public void testRender() {
		assertEquals("render() Error!", '+', s.render());
	}
	@Test
	public void testRoad() {
		assertEquals("Constructor Road parameter 1 Error!", 1, s.GetKoordinat().GetAbsis());
		assertEquals("Constructor Road parameter 1 Error!", 4, s.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testFacility() {
		assertEquals("Constructor Facility parameter 1 Error!", 1, s.GetKoordinat().GetAbsis());
		assertEquals("Constructor Facility parameter 1 Error!", 4, s.GetKoordinat().GetOrdinat());
		assertEquals("Constructor Facility parameter 2 Error!", true, s.IsRoad());
		assertEquals("Constructor Facility parameter 2 Error!", false, s.IsRestaurant());
		assertEquals("Constructor Facility parameter 2 Error!", false, s.IsPark());
		assertEquals("Constructor Facility parameter 3 Error!", 's', s.GetCode());
	}
	@Test
	public void testIsRoad() {
		assertEquals("IsRoad() Error!", true, s.IsRoad());
	}
	@Test
	public void testIsPark() {
		assertEquals("IsPark() Error!", false, s.IsPark());
	}
	@Test
	public void testIsRestaurant() {
		assertEquals("IsRestaurant() Error!", false, s.IsRestaurant());
	}
	@Test
	public void testCell() {
		assertEquals("Constructor Cell parameter 1 Error!", 1, s.GetKoordinat().GetAbsis());
		assertEquals("Constructor Cell parameter 1 Error!", 4, s.GetKoordinat().GetOrdinat());
		assertEquals("Constructor Cell parameter 2 Error!", true, s.IsFacility());
		assertEquals("Constructor Cell parameter 2 Error!", false, s.IsHabitat());
		assertEquals("Constructor Cell parameter 3 Error!", 's', s.GetCode());
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("GetKoordinat() Error!", 1, s.GetKoordinat().GetAbsis());
		assertEquals("GetKoordinat() Error!", 4, s.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testIsHabitat() {
		assertEquals("IsHabitat() Error!", false, s.IsHabitat());
	}
	@Test
	public void testIsFacility() {
		assertEquals("IsHabitat() Error!", true, s.IsFacility());
	}
	@Test
	public void testGetCode() {
		assertEquals("GetCode() Error!", 's', s.GetCode());
	}
}