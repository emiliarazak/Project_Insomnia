/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cell.habitat;
import cell.Cell;
import indices.Indices;
/**
*
* @author Emil
*/
public abstract class Habitat extends Cell {
  /** @brief Attribut Htype yang adalah type dari habitat
      */
      protected int hType;
       /** @brief Constructor dari Habitat
      * Menghidupkan habitat
      *
      * @param I Indices adalah alamat dimana habitat dihidupkan
      * @param type integer adalah kode dari habitat dimana 0=Land, 1=Water, 2=Air
      * @param code character adalah suatu huruf untuk merepresentasikan habitat di layar.
      */
      public Habitat(Indices ind, int type, char code) {
        super(ind, 0, code);
        hType=type;
      }
       /** @brief Mengembalikan nilai boolean apakah habitat adalah land
      */
      public final boolean IsLand() {
        return (hType==0);
       }
       /** @brief Mengembalikan nilai boolean apakah habitat adalah water
      */
      public final boolean IsWater() {
        return (hType==1);
      }
       /** @brief Mengembalikan nilai boolean apakah habitat adalah air
      */
      public final boolean IsAir() {
        return (hType==2);
      }
}