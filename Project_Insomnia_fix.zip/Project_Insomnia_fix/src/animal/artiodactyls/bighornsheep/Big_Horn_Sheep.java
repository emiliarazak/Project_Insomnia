/**
 * 
 */

package animal.artiodactyls.bighornsheep;

import animal.artiodactyls.Artiodactyls;
import renderable.Renderable;

/**Real Class Big_Horn_Sheep.
 * @author Luthfi Fadillah
 *
 */
public class Big_Horn_Sheep extends Artiodactyls implements Renderable {
  /** Constructor dari Big_Horn_Sheep.
   *
   * @param x : bertipe int, adalah letak absis Big_Horn_Sheep yang dihidupkan.
   * @param y : bertipe int, adalah letak ordinat Big_Horn_Sheep yang dihidupkan.
   * @param bb : bertipe int, adalah berat badan Big_Horn_Sheep yang dihidupkan.
   */
  public Big_Horn_Sheep(int bb, int x, int y) {
    super(false,x,y);
    SetBerat(bb);
    setInteraction("Mbeeeekkkk");
  }

  /** Mengembalikan nilai character kode dari objek Big_Horn_Sheep.
   * @return char : kode yang nantinya siap dicetak ke layar.
   */
  public char render() { 
    return 'S';
  }
}