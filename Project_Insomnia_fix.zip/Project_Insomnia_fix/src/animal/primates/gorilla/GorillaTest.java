/**
 * 
 */
package animal.primates.gorilla;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import animal.primates.gorilla.Gorilla;

/** Tes untuk kelas Gorilla
 * 
 * @author suzaneringoringo
 *
 */
public class GorillaTest {
  
  public GorillaTest() {
  }
  
  @BeforeClass
  public static void setUpClass() {
  }

  @AfterClass
  public static void tearDownClass() {
  }

  /**
   * Tes metode Interact pada kelas Gorilla.
   */
  @Test
  public void testInteract() {
    System.out.println("Interact");
    Gorilla instance = new Gorilla(70,3,3);
    instance.Interact();
  }
  
  /**
   * Tes metode SetBerat dan GetBerat pada kelas Gorilla.
   */
  @Test
  public void testSetGetBerat() {
    System.out.println("SetBerat dan GetBerat");
    Gorilla instance = new Gorilla(70,3,3);
    int gb;
    gb = instance.GetBerat();
    assertEquals("Salah berat",gb,70);
  }
  
  /**
   *  Tes metode SetKoordinat dan GetKoordinat pada kelas Gorilla.
   */
  @Test
  public void testSetGetKoordinat() {
    System.out.println("SetKoordinat dan GetKoordinat");
    Gorilla instance = new Gorilla(70,1,1);
    int xresult = 3;
    int yresult = 3;
    instance.SetKoordinat(xresult, yresult);
    assertEquals("Salah x", xresult, instance.GetKoordinat().GetAbsis());
    assertEquals("Salah y", yresult, instance.GetKoordinat().GetOrdinat());
  }
  
  /**
   * Tes metode IsLandAnimal, IsWaterAnimal, and IsAirAnimal pada kelas Gorilla.
   */
  @Test
  public void testHabitatAnimal() {
    System.out.println("IsLandAnimal, IsWaterAnimal, and IsAirAnimal");
    Gorilla instance = new Gorilla(70,1,1);
    boolean land = true;
    boolean water = false;
    boolean air = false;
    assertEquals("Salah land", land, instance.IsLandAnimal());
    assertEquals("Salah water", water, instance.IsWaterAnimal());
    assertEquals("Salah land", air, instance.IsAirAnimal());
  }
  
  /**
   * Tes metode IsJinak method pada kelas Gorilla.
   */
  @Test
  public void testIsJinak() {
    System.out.println("IsJinak");
    Gorilla instance = new Gorilla(70,1,1);
    boolean jinak = true;
    assertEquals("Salah jinak", jinak, instance.IsJinak());
  }
  
  /**
   * Tes metode IsJinak pada kelas Gorilla.
   */
  @Test
  public void testGetMakanan() {
    System.out.println("IsJinak");
    Gorilla instance = new Gorilla(70,1,1);
    int makan = 1;
    assertEquals("Salah makan", makan, instance.GetMakanan());
  }
  
  /**
   * Tes metode Render pada kelas Gorilla.
   */
  @Test
  public void testRender() {
    System.out.println("Render");
    Gorilla instance = new Gorilla(70,1,1);
    char render = 'J';
    assertEquals("Salah render", render, instance.render());
  }
}
