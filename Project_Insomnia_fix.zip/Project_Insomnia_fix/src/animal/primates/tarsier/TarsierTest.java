/**
 * 
 */
package animal.primates.tarsier;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import animal.primates.tarsier.Tarsier;

/** Tes untuk kelas Tarsier
 * 
 * @author suzaneringoringo
 *
 */
public class TarsierTest {
  
  public TarsierTest() {
  }
  
  @BeforeClass
  public static void setUpClass() {
  }

  @AfterClass
  public static void tearDownClass() {
  }

  /**
   * Tes metode Interact pada kelas Tarsier.
   */
  @Test
  public void testInteract() {
    System.out.println("Interact");
    Tarsier instance = new Tarsier(70,3,3);
    instance.Interact();
  }
  
  /**
   * Tes metode SetBerat dan GetBerat pada kelas Tarsier.
   */
  @Test
  public void testSetGetBerat() {
    System.out.println("SetBerat dan GetBerat");
    Tarsier instance = new Tarsier(70,3,3);
    int gb;
    gb = instance.GetBerat();
    assertEquals("Salah berat",gb,70);
  }
  
  /**
   *  Tes metode SetKoordinat dan GetKoordinat pada kelas Tarsier.
   */
  @Test
  public void testSetGetKoordinat() {
    System.out.println("SetKoordinat dan GetKoordinat");
    Tarsier instance = new Tarsier(70,1,1);
    int xresult = 3;
    int yresult = 3;
    instance.SetKoordinat(xresult, yresult);
    assertEquals("Salah x", xresult, instance.GetKoordinat().GetAbsis());
    assertEquals("Salah y", yresult, instance.GetKoordinat().GetOrdinat());
  }
  
  /**
   * Tes metode IsLandAnimal, IsWaterAnimal, and IsAirAnimal pada kelas Tarsier.
   */
  @Test
  public void testHabitatAnimal() {
    System.out.println("IsLandAnimal, IsWaterAnimal, and IsAirAnimal");
    Tarsier instance = new Tarsier(70,1,1);
    boolean land = true;
    boolean water = false;
    boolean air = false;
    assertEquals("Salah land", land, instance.IsLandAnimal());
    assertEquals("Salah water", water, instance.IsWaterAnimal());
    assertEquals("Salah land", air, instance.IsAirAnimal());
  }
  
  /**
   * Tes metode IsJinak method pada kelas Tarsier.
   */
  @Test
  public void testIsJinak() {
    System.out.println("IsJinak");
    Tarsier instance = new Tarsier(70,1,1);
    boolean jinak = true;
    assertEquals("Salah jinak", jinak, instance.IsJinak());
  }
  
  /**
   * Tes metode IsJinak pada kelas Tarsier.
   */
  @Test
  public void testGetMakanan() {
    System.out.println("IsJinak");
    Tarsier instance = new Tarsier(70,1,1);
    int makan = 1;
    assertEquals("Salah makan", makan, instance.GetMakanan());
  }
  
  /**
   * Tes metode Render pada kelas Tarsier.
   */
  @Test
  public void testRender() {
    System.out.println("Render");
    Tarsier instance = new Tarsier(70,1,1);
    char render = 'F';
    assertEquals("Salah render", render, instance.render());
  }
}
