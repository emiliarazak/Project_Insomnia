package gui;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.*;
import javax.swing.*;

/**
 * @author Luthfi Fadillah
 * Class DisplayMenu
 * Class graphical user interface untuk menampilkan menu awal dan memilih menu
 */

@SuppressWarnings({ "serial", "unused" })
public class DisplayMenu extends JPanel {
  /**
   * Method untuk menampilkan panel introduksi
   * I.S. : -
   * F.S. : Kata-kata sambutan ke VirtualZoo ditampilkan ke layar
   */
    private final JFrame frame = new JFrame("VirtualZoo");

  /**
   * Class constructor.
   */
  public DisplayMenu() {
    Container panel = frame.getContentPane();
    panel.setLayout(null);
    panel.setBackground(Color.PINK);
    JLabel Map = new JLabel("Virtual Zoo");
    Map.setBounds(130, 60, 220, 30);
    Map.setFont(new Font("Arial", Font.BOLD,24));
    JButton button1 = new JButton ("Play!");
    button1.setBounds(80, 100, 220, 30);

    JButton button2 = new JButton("Exit");
    button2.setBounds(80, 130, 220, 30);
    
    panel.add(Map);
    panel.add(button1);
    panel.add(button2);
    
    button1.addActionListener(
        new ActionListener() {
          @Override
          public void actionPerformed (ActionEvent e){
        	  Play buff = new Play();
          }
        }
    );

    button2.addActionListener(
        new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
        	  System.exit(0);
          }
        }
    );


    frame.setSize(400, 300);
    frame.setVisible(true);
    frame.setLocationRelativeTo(null);
    frame.setResizable(true);
    frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

  }
}