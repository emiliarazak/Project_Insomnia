package gui;
import java.util.HashMap;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

/**
 * @author Luthfi Fadillah
 * Class Music
 * Class untuk mengolah musik.
 */
public class Music {
	
	private static HashMap<String, Clip> clips;
	private static int gap;
	private static boolean mute = false;
	
	  /**
	   * Method untuk inisialisasi daftar musik.
	   */
	public static void init() {
		clips = new HashMap<String, Clip>();
		gap = 0;
	}
	
	  /**
	   * Method untuk memasukkan musik.
	   */
	public static void load(String s, String n) {
		if(clips.get(n) != null) return;
		Clip clip;
		try {			
			AudioInputStream ais =
				AudioSystem.getAudioInputStream(
					Music.class.getResourceAsStream(s)
				);
			AudioFormat baseFormat = ais.getFormat();
			AudioFormat decodeFormat = new AudioFormat(
				AudioFormat.Encoding.PCM_SIGNED,
				baseFormat.getSampleRate(),
				16,
				baseFormat.getChannels(),
				baseFormat.getChannels() * 2,
				baseFormat.getSampleRate(),
				false
			);
			AudioInputStream dais = AudioSystem.getAudioInputStream(decodeFormat, ais);
			clip = AudioSystem.getClip();
			clip.open(dais);
			clips.put(n, clip);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	  /**
	   * Method untuk memulai musik.
	   * @param s nama lagu di daftar lagu
	   */
	public static void play(String s) {
		play(s, gap);
	}

	  /**
	   * Method untuk memulai musik.
	   * @param s nama lagu di daftar lagu
	   * @param i waktu dimulainya lagu
	   */
	public static void play(String s, int i) {
		if(mute) return;
		Clip c = clips.get(s);
		if(c == null) return;
		if(c.isRunning()) c.stop();
		c.setFramePosition(i);
		while(!c.isRunning()) c.start();
	}
	
	  /**
	   * Method untuk stop musik.
	   * @param s nama lagu di daftar lagu
	   */
	public static void stop(String s) {
		if(clips.get(s) == null) return;
		if(clips.get(s).isRunning()) clips.get(s).stop();
	}
	
	  /**
	   * Method untuk meneruskan musik.
	   * @param s nama lagu di daftar lagu
	   */
	public static void resume(String s) {
		if(mute) return;
		if(clips.get(s).isRunning()) return;
		clips.get(s).start();
	}
	
	  /**
	   * Method untuk memainkan musik secara berulang-ulang.
	   * @param s nama lagu di daftar lagu
	   */
	public static void loop(String s) {
		loop(s, gap, gap, clips.get(s).getFrameLength() - 1);
	}
	
	  /**
	   * Method untuk memainkan musik secara berulang-ulang.
	   * @param s nama lagu di daftar lagu
	   * @param frame panjang lagu
	   */
	public static void loop(String s, int frame) {
		loop(s, frame, gap, clips.get(s).getFrameLength() - 1);
	}
	
	  /**
	   * Method untuk memainkan musik secara berulang-ulang.
	   * @param s nama lagu di daftar lagu
	   * @param start awal lagu
	   * @param end akhir lagu
	   */
	public static void loop(String s, int start, int end) {
		loop(s, gap, start, end);
	}
	
	  /**
	   * Method untuk memainkan musik secara berulang-ulang.
	   * @param s nama lagu di daftar lagu
	   * @param frame awal mulai lagu
	   * @param start awal lagu
	   * @param end akhir lagu
	   */
	public static void loop(String s, int frame, int start, int end) {
		stop(s);
		if(mute) return;
		clips.get(s).setLoopPoints(start, end);
		clips.get(s).setFramePosition(frame);
		clips.get(s).loop(Clip.LOOP_CONTINUOUSLY);
	}
	
	  /**
	   * Method set posisi lagu
	   * @param s nama lagu
	   * @param frame posisi lagu
	   */
	public static void setPosition(String s, int frame) {
		clips.get(s).setFramePosition(frame);
	}
	
	  /**
	   * Method untuk mendapatkan panjang lagu
	   * @param s nama lagu
	   */
	public static int getFrames(String s) { return clips.get(s).getFrameLength(); }
	
	  /**
	   * Method untuk mendapatkan posisi lagu
	   * @param s nama lagu
	   */
	public static int getPosition(String s) { return clips.get(s).getFramePosition(); }
	
	  /**
	   * Method untuk membersihkan lagu yang dimasukkan
	   * @param s nama lagu
	   */
	public static void close(String s) {
		stop(s);
		clips.get(s).close();
	}
	
}