package gui;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import zoo.Zoo;

/**
 * @author Luthfi Fadillah
 * Class Play
 * Class graphical user interface untuk menampilkan peta serta memulai 
 * menggerakkan player
 */

public class Play implements KeyListener {
	
	private Zoo z;
	private Container panel;
	private JFrame frame;
	
	  /**
	   * Class untuk display peta.
	   */
	public void DisplayMap(){
		frame = new JFrame("Display Virtual Zoo");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 500);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
		panel = frame.getContentPane();
        panel.setLayout(null);
        panel.addKeyListener(this);
        panel.setFocusable(true);

        JButton button1 = new JButton("Back to Main Menu");
        button1.setBounds(0, 400, 200, 30);
        panel.add(button1);
        button1.addActionListener(
            new ActionListener() {
              @Override
              public void actionPerformed(ActionEvent e) {
            	Music.stop("backsound");
            	frame.dispose();
              }
            }
        );
        z.PrintGUI(panel);
	}
	
	  /**
	   * Class constructor.
	   */	
	public Play(){
		Music.init();
		Music.load("/Music/backsound.mp3", "backsound");
		
		try {
			z = new Zoo();
		} catch (IOException e) {
			e.printStackTrace();
		}
		Music.loop("backsound");
		DisplayMap();
	}
	
	  /**
	   * Method turunan untuk menangkap tombol yang ditekan.
	   * @param key tombol yang ditekan
	   */
	public void keyPressed(KeyEvent key) {
		if (key.getKeyCode() == KeyEvent.VK_SPACE){
			info();
		}
		if(key.getKeyCode() == KeyEvent.VK_UP){
			if(isJalanAble(key)){
				z.SetPlayerPos(z.GetPlayerPos().GetAbsis(), z.GetPlayerPos().GetOrdinat()-1);
			}
			z.Move();
			update();
			if(isFinish()){
				finish();
			}
		}
		if(key.getKeyCode() == KeyEvent.VK_DOWN){
			if(isJalanAble(key)){
				z.SetPlayerPos(z.GetPlayerPos().GetAbsis(), z.GetPlayerPos().GetOrdinat()+1);
			}
			z.Move();
			update();
			if(isFinish()){
				finish();
			}
		}
		if(key.getKeyCode() == KeyEvent.VK_LEFT){
			if(isJalanAble(key)){
				z.SetPlayerPos(z.GetPlayerPos().GetAbsis()-1, z.GetPlayerPos().GetOrdinat());
			}
			z.Move();
			update();
			if(isFinish()){
				finish();
			}
		}
		if(key.getKeyCode() == KeyEvent.VK_RIGHT){
			if(isJalanAble(key)){
				z.SetPlayerPos(z.GetPlayerPos().GetAbsis()+1, z.GetPlayerPos().GetOrdinat());
			}
			z.Move();
			update();
			if(isFinish()){
				finish();
			}
		}
	}
	
	  /**
	   * Method untuk melakukan update.
	   */
	public void update(){
		frame.dispose();
		DisplayMap();
	}
	
	  /**
	   * Method untuk mengecek apakah player bisa jalan.
	   * @param key tombol yang ditekan
	   */	
	private boolean isJalanAble(KeyEvent key){
		boolean able = false;
		if(key.getKeyCode() == KeyEvent.VK_UP){
			if(z.GetPlayerPos().GetOrdinat()-1 >= 0){
				if((z.GetPlayerMap()[z.GetPlayerPos().GetOrdinat()-1][z.GetPlayerPos().GetAbsis()] == '-' || z.GetPlayerMap()[z.GetPlayerPos().GetOrdinat()-1][z.GetPlayerPos().GetAbsis()] == '+' || z.GetPlayerMap()[z.GetPlayerPos().GetOrdinat()-1][z.GetPlayerPos().GetAbsis()] == '=')){
					able = true;
				}
			}
		}
		if(key.getKeyCode() == KeyEvent.VK_DOWN){
			if (z.GetPlayerPos().GetOrdinat()+1 < z.GetLebar()){
				if((z.GetPlayerMap()[z.GetPlayerPos().GetOrdinat()+1][z.GetPlayerPos().GetAbsis()] == '-' || z.GetPlayerMap()[z.GetPlayerPos().GetOrdinat()+1][z.GetPlayerPos().GetAbsis()] == '+' || z.GetPlayerMap()[z.GetPlayerPos().GetOrdinat()+1][z.GetPlayerPos().GetAbsis()] == '=')){
					able = true;
				}
			}
		}
		if(key.getKeyCode() == KeyEvent.VK_LEFT){
			if(z.GetPlayerPos().GetAbsis()-1 >= 0){
				if((z.GetPlayerMap()[z.GetPlayerPos().GetOrdinat()][z.GetPlayerPos().GetAbsis()-1] == '-' || z.GetPlayerMap()[z.GetPlayerPos().GetOrdinat()][z.GetPlayerPos().GetAbsis()-1] == '+' || z.GetPlayerMap()[z.GetPlayerPos().GetOrdinat()][z.GetPlayerPos().GetAbsis()-1] == '=')){
					able = true;
				}
			}
		}
		if(key.getKeyCode() == KeyEvent.VK_RIGHT){
			if (z.GetPlayerPos().GetAbsis()+1 < z.GetPanjang()){
				 if((z.GetPlayerMap()[z.GetPlayerPos().GetOrdinat()][z.GetPlayerPos().GetAbsis()+1] == '-' || z.GetPlayerMap()[z.GetPlayerPos().GetOrdinat()][z.GetPlayerPos().GetAbsis()+1] == '+' || z.GetPlayerMap()[z.GetPlayerPos().GetOrdinat()][z.GetPlayerPos().GetAbsis()+1] == '=')){
					able = true;
				}
			}
		}		
		return able;
	}
	
	  /**
	   * method untuk mengecek apakah player telah mencapai pintu keluar.
	   */
	public boolean isFinish(){
		return(z.GetPrint()[z.GetPlayerPos().GetOrdinat()][z.GetPlayerPos().GetAbsis()] == '=');
	}
	
	  /**
	   * Method untuk memunculkan dialog box ketika selesai.
	   */
	public void finish(){
	    JFrame frameexit = new JFrame();
	    String text = "Hooray, you found the exit!";
	    JOptionPane.showMessageDialog(frameexit, text, "Congratulations!", JOptionPane.PLAIN_MESSAGE);
	    Music.stop("backsound");
	    frame.dispose();
	}
	
	  /**
	   * method untuk memunculkan informasi.
	   */
	public void info(){
	    JFrame frameinfo = new JFrame();
	    String text =  "Legend\n"
	    + "B: Beluga, S: Big Horn Sheep, C: Cassowary, H: Chameleon, T: Cheetah\n"
	    + "O: Cockatoo, D: Deer, N: Dolphin, U: Duck, G: Giraffe\n"
	    + "J: Gorilla, K: Great White Shark, E: Lemur, I: Lion, M: Meerkat\n"
	    + "Y: Monkey, $: Orca, Z: Owl, X: Parrot, V: Python\n"
	    + "Q: Swan, F: Tarsier, @: Wolf, P: Park, R: Restaurant\n"
	    + "L: Land Habitat, W: Water Habitat, A: Air Habitat, -: Road, +: Entrance\n"
	    + "=: Exit";
	    JOptionPane.showMessageDialog(frameinfo, text, "Legend", JOptionPane.PLAIN_MESSAGE);		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}