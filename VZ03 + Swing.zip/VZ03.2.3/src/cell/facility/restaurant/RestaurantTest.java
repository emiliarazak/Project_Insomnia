package cell.facility.restaurant;
import static org.junit.Assert.*;
import org.junit.Test;

import indices.Indices;
/**
*
* @author Emil
*/
public class RestaurantTest {
	private Indices ind = new Indices(3,4);
	private Restaurant r = new Restaurant(ind);
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'R', r.render());
	}
	@Test
	public void testRestaurant() {
		assertEquals("Constructor Restaurant parameter 1 Error!", 3, r.GetKoordinat().GetAbsis());
		assertEquals("Constructor Restaurant parameter 1 Error!", 4, r.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testFacility() {
		assertEquals("Constructor Facility parameter 1 Error!", 3, r.GetKoordinat().GetAbsis());
		assertEquals("Constructor Facility parameter 1 Error!", 4, r.GetKoordinat().GetOrdinat());
		assertEquals("Constructor Facility parameter 2 Error!", true, r.IsRestaurant());
		assertEquals("Constructor Facility parameter 2 Error!", false, r.IsRoad());
		assertEquals("Constructor Facility parameter 2 Error!", false, r.IsPark());
		assertEquals("Constructor Facility parameter 3 Error!", 'r', r.GetCode());
	}
	@Test
	public void testIsRoad() {
		assertEquals("IsRoad() Error!", false, r.IsRoad());
	}
	@Test
	public void testIsPark() {
		assertEquals("IsPark() Error!", false, r.IsPark());
	}
	@Test
	public void testIsRestaurant() {
		assertEquals("IsPark() Error!", true, r.IsRestaurant());
	}
	@Test
	public void testCell() {
		assertEquals("Constructor Cell parameter 1 Error!", 3, r.GetKoordinat().GetAbsis());
		assertEquals("Constructor Cell parameter 1 Error!", 4, r.GetKoordinat().GetOrdinat());
		assertEquals("Constructor Cell parameter 2 Error!", true, r.IsFacility());
		assertEquals("Constructor Cell parameter 2 Error!", false, r.IsHabitat());
		assertEquals("Constructor Cell parameter 3 Error!", 'r', r.GetCode());
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("GetKoordinat() Error!", 3, r.GetKoordinat().GetAbsis());
		assertEquals("GetKoordinat() Error!", 4, r.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testIsHabitat() {
		assertEquals("IsHabitat() Error!", false, r.IsHabitat());
	}
	@Test
	public void testIsFacility() {
		assertEquals("IsFacility() Error!", true, r.IsFacility());
	}
	@Test
	public void testGetCode() {
		assertEquals("GetCode() Error!", 'r', r.GetCode());
	}

}