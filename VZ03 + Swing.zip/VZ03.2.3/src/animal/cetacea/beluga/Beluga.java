/**
 * 
 */

package animal.cetacea.beluga;

import animal.cetacea.Cetacea;
import renderable.Renderable;

/**Real Class Beluga.
 * @author Luthfi Fadillah
 *
 */

public class Beluga extends Cetacea implements Renderable {
  /** Constructor dari Beluga.
   * Menghidupkan hewan Beluga.
   *
   * @param x : bertipe int, adalah letak absis Beluga yang dihidupkan.
   * @param y : bertipe int, adalah letak ordinat Beluga yang dihidupkan.
   * @param bb : bertipe int, adalah berat badan Beluga yang dihidupkan.
   */
  
  public Beluga(int bb, int x, int y) {
    super(true, x, y);
    SetBerat(bb);
    setInteraction("Ooooooooooooo...");
  }
  
  /** Mengembalikan nilai character kode dari objek Beluga.
   * @return char : kode yang nantinya siap dicetak ke layar.
   */
  
  public char render() {
    return 'B';
  }
}