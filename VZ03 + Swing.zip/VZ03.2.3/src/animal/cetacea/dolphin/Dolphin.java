/**
 * 
 */

package animal.cetacea.dolphin;

import animal.cetacea.Cetacea;
import renderable.Renderable;

/**Real Class Dolphin.
 * @author Luthfi Fadillah
 *
 */

public class Dolphin extends Cetacea implements Renderable {
  /** Constructor dari Dolphin.
   * Menghidupkan hewan Dolphin.
   *
   * @param x : bertipe int, adalah letak absis Dolphin yang dihidupkan.
   * @param y : bertipe int, adalah letak ordinat Dolphin yang dihidupkan.
   * @param bb : bertipe int, adalah berat badan Dolphin yang dihidupkan.
   */
  
  public Dolphin(int bb, int x, int y) {
    super(true, x, y);
    SetBerat(bb);
    setInteraction("Bermain bola? Makan dulu");
  }
  
  /** Mengembalikan nilai character kode dari objek Dolphin.
   * @return char : kode yang nantinya siap dicetak ke layar.
   */
  
  public char render() {
    return 'N';
  }
}