/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animal.anseriformes;
import animal.Animal;
/**
*
* @author Emil
*/
public abstract class Anseriformes extends Animal {
  /** @brief Constructor dari Anseriformes
      * Menghidupkan hewan Ordo Anseriformes
      *
      * @param x integer adalah letak absis Anseriformes yang dihidupkan
      * @param y integer adalah letak ordinat Anseriformes yang dihidupkan
      * @param kejinakan boolean menyatakan jinak tidaknya hewan
      */    
    public Anseriformes(boolean kejinakan, int x, int y) {
      super(1, true, true, false,kejinakan, x,y);
    }
}