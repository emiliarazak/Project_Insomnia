/**
 * 
 */

package animal.casuariformes;

import animal.Animal;

/** Kelas ordo Casuariformes.
 * 
 * @author Alivia Dewi Parahita
 *
 */
public abstract class Casuariformes extends Animal {
  /** Constructor dari Casuariformes.
   * Menghidupkan hewan Ordo Casuariformes.
   *
   * @param x integer adalah letak absis Casuariformes yang dihidupkan
   * @param y integer adalah letak ordinat Casuariformes yang dihidupkan
   * @param kejinakan boolean menyatakan jinak tidaknya hewan
   */
  
  public Casuariformes(boolean kejinakan, int x, int y) {
    super(1, true, false, false,kejinakan,x,y);
  }
}
