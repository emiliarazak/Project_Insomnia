/**
 * 
 */

package animal.carnivora.cheetah;

import animal.carnivora.Carnivora;

/** Kelas spesies Cheetah.
 * 
 * @author Suzane Ringoringo
 *
 */
public final class Cheetah extends Carnivora {
  /** Constructor dari Cheetah.
   * Menghidupkan hewan Cheetah.
   *
   * @param x integer adalah letak absis Cheetah yang dihidupkan
   * @param y integer adalah letak ordinat Cheetah yang dihidupkan
   * @param bb integer adalah berat badan Cheetah yang dihidupkan
   */
  
  public Cheetah(int bb, int x, int y) {
    super(false, x, y);
    SetBerat(bb);
    setInteraction("*runs so swiftly*");
  }

  @Override
  /** fungsi Render dari objek Cheetah
   * Mengembalikan kode Cheetah pada layar
   * 
   * @return char
   */
  public char render() {
    return 'T';
  }
}
