package board;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

@SuppressWarnings("serial")
public class Board extends JPanel {
	public static final int WIDTH = 320;
	public static final int HEIGHT = 240;
	public static final int SCALE = 2;
	private Image[][] tile;
	
	
	public Board() throws IOException{
		initBoard();
	}
	
	private void initBoard() throws IOException{
		
		loadMap();
		
		int w = WIDTH*SCALE;
		int h = HEIGHT*SCALE;
		setPreferredSize(new Dimension(w,h));
	}
	
	private void loadMap() throws IOException{
		BufferedReader br = new BufferedReader (new FileReader("src/board/map.txt"));
		int[][] map = new int[20][15];
		String strLine;
		
		for(int y = 0;y<15;y++){
			strLine = br.readLine();
			for(int x = 0; x<20 ; x++){
				map[x][y] = (int) strLine.charAt(x) - 48;
			}
		}
		br.close();
		ImageIcon[][] ii = new ImageIcon[20][15];
		
		for(int y = 0; y<15; y++){
			for(int x = 0; x<20 ; x++){
				ii[x][y] = new ImageIcon("src/board/"+map[x][y]+".png");
			}
		}
		
		tile = new Image[20][15];
		for(int y=0;y<15;y++){
			for(int x=0;x<20;x++){
				tile[x][y] = ii[x][y].getImage();
			}
		}
	}
	
	@Override
	public void paintComponent(Graphics g){
		for(int y = 0; y<15 ; y++){
			for(int x = 0 ; x<20 ; x++){
				g.drawImage(tile[x][y],32*x,32*y,null);
			}
		}
	}
}
