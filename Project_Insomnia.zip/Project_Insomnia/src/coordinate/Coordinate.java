/**
 * 
 */
package coordinate;

/**
 * @author ASUS-ROG
 *
 */
public class Coordinate {
	  /** Attribut x adalah nilai absis indeks.
	   */

	  protected int absis;
	  
	  /** Attribut y adalah nilai ordinat indeks.
	   */
	  
	  protected int ordinat;
	  
	  /** Constructor tanpa parameter dari Coordinate.
	   * Menghidupkan indeks
	   */

	  public Coordinate() {
	    absis = 0;
	    ordinat = 0;
	  }
	  
	  /** Constructor dengan parameter dari Coordinate.
	   * Menghidupkan indeks sesuai parameter
	   *
	   * @param absis integer adalah absis yang akan di set
	   * @param ordinat integer adalah ordinat yang akan di set
	   */
	  
	  public Coordinate(int absis, int ordinat) {
	    this.absis = absis;
	    this.ordinat = ordinat;
	  }
	  
	  /** Operator overloading = dari Coordinate.
	   * Memastikan bukan bitewise copy
	   *
	   * @param ind menyatakan Coordinate yang ingin disalin
	   */
	  
	  public void copyCoordinate(Coordinate ind) {
	    absis = ind.getAbsis();
	    ordinat = ind.getOrdinat();
	  }
	  
	  /** getAbsis dari Coordinate.
	   * Mengembalikan nilai absis dari indeks
	   *
	   */
	  
	  public int getAbsis() {
	    return absis;
	  }
	  
	  /** getOrdinat dari Coordinate.
	   * Mengembalikan nilai ordinat dari indeks
	   *
	   */
	  
	  public int getOrdinat() {
	    return ordinat;
	  }
	  
	  /** Prosedur setAbsis dari Coordinate.
	   * I.S Coordinate sudah hidup dan masukan terdefinisi
	   * F.S Absis Coordinate nilai menjadi masukan
	   *
	   * @param x integer adalah nilai absis yang akan di set
	   */
	  
	  public void setAbsis(int x) {
	    this.absis = x;
	  }
	  
	  /** Prosedur setOrdinat dari Coordinate.
	   * I.S Coordinate sudah hidup dan masukan terdefinisi
	   * F.S Ordinat Coordinate nilai menjadi masukan
	   *
	   * @param y integer adalah nilai ordinat yang akan di set
	   */
	  
	  public void setOrdinat(int y) {
	    this.ordinat = y;
	  }
	  
	  /** Mengembalikan nilai booleanean apakah Coordinate masukan sama dengan current objek.
	   *
	   * @param ind Coordinate yang ingin dibandingkan dengan current objek
	   */
	  
	  public boolean isEqual(Coordinate ind) {
	    return ((this.absis == ind.getAbsis()) && (this.ordinat == ind.getOrdinat()));
	  }
	  
	  public void printKoordinat() {
	    System.out.println("(" + absis + ", " + ordinat + ")");
	  }
}
