package app;

import board.Board;
import java.awt.EventQueue;
import java.io.IOException;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class Application extends JFrame {

	public Application() throws IOException{
		initUI();
	}
	
	private void initUI() throws IOException{
		add(new Board());
		
		pack();
		
		setTitle("Map");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				JFrame ex = null;
				try {
					ex = new Application();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				ex.setVisible(true);
			}
		});
	}

}
