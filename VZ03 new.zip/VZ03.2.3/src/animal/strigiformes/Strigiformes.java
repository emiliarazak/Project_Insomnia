package animal.strigiformes;

import animal.Animal;

/**Abstract Class Strigiformes.
 * @author Alivia Dewi Parahita
 *
 */
public abstract class Strigiformes extends Animal {
  /** Constructor dari Strigiformes.
   * Menghidupkan hewan Ordo Strigiformes.
   *
   * @param x : bertipe int, adalah letak absis Strigiformes yang dihidupkan. 
   * @param y : bertipe int, adalah letak ordinat Strigiformes yang dihidupkan.
   * @param kejinakan : bertipe bool, menyatakan jinak tidaknya hewan.
   */
  
  public Strigiformes(boolean kejinakan, int x, int y) {
    super(1,false,false,true,kejinakan,x,y);
  }
}
