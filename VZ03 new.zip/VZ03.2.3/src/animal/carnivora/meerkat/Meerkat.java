/**
 * 
 */

package animal.carnivora.meerkat;

import animal.carnivora.Carnivora;

/** Kelas spesies Meerkat.
 * 
 * @author Suzane Ringoringo
 *
 */
public final class Meerkat extends Carnivora {

  /** Constructor dari Meerkat.
   * Menghidupkan hewan Meerkat.
   *
   * @param x integer adalah letak absis Meerkat yang dihidupkan
   * @param y integer adalah letak ordinat Meerkat yang dihidupkan
   * @param bb integer adalah berat badan Meerkat yang dihidupkan
   */
  public Meerkat(int bb, int x, int y) {
    super(false, x, y);
    SetBerat(bb);
    setInteraction("*stands*");
  }
  
  @Override
  /** fungsi Render dari objek Meerkat
    * Mengembalikan kode Meerkat pada layar
    * 
    * @return char
    */
  public char render() {
    return 'M';
  }
}
