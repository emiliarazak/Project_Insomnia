/**
 * 
 */

package animal.cetacea;

import animal.Animal;

/**Abstract Class Cetacea.
 * @author Luthfi Fadillah
 *
 */
public abstract class Cetacea extends Animal {
  /** Constructor dari Cetacea.
   * Menghidupkan hewan Ordo Cetacea.
   *
   * @param x : bertipe int, adalah letak absis Cetacea yang dihidupkan.
   * @param y : bertipe int, adalah letak ordinat Cetacea yang dihidupkan.
   * @param kejinakan : bertipe bool, menyatakan jinak tidaknya hewan.
   */

  public Cetacea(boolean kejinakan, int x, int y) {
    super(0,true,false,false,kejinakan,x,y);
  }
}