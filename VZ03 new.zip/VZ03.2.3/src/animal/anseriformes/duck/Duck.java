/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animal.anseriformes.duck;
import renderable.Renderable;
import animal.anseriformes.Anseriformes;
/**
*
* @author Emil
*/
public class Duck extends Anseriformes implements Renderable {
  /** @brief Constructor dari Duck
      * Menghidupkan hewan Duck
      *
      * @param x integer adalah letak absis Duck yang dihidupkan
      * @param y integer adalah letak ordinat Duck yang dihidupkan
      * @param bb integer adalah berat badan Duck yang dihidupkan
      */
    public Duck(int bb, int x, int y) {
      super(true, x, y);
      SetBerat(bb);
      setInteraction("Qwekk qwekk");
    }
    /** @brief Mengembalikan nilai character kode dari objek Duck
      * Character ini nantinya yang siap dicetak ke layar
      */
    public char render() {
      return 'U';
    }
}