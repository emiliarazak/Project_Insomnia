package animal.selachimorpha.greatwhiteshark;
import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
/**
*
* @author Emil
*/ 
public class GreatWhiteSharkTest {
	private GreatWhiteShark k = new GreatWhiteShark(2000,1,2);
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	
	@Before
	public void setUpStreams() {
		System.setOut(new PrintStream(outContent));
	}
	@After
	public void cleanUpStreams() {
		System.setOut(null);
	}
	@Test
	public void testInteract() {
		k.Interact();
		assertEquals("Interact() Error!", "*Big grins* heyyo\n", outContent.toString());
	}
	@Test
	public void testGreatWhiteShark() {
		assertEquals("Constructor GreatWhiteShark parameter 1 Error!", 2000, k.GetBerat());
		assertEquals("Constructor GreatWhiteShark parameter 2 Error!", 1, k.GetKoordinat().GetAbsis());
		assertEquals("Constructor GreatWhiteShark parameter 3 Error!", 2, k.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'K', k.render());
	}
	@Test
	public void testSelachimorpha() {
		assertEquals("Constructor Selachimorpha parameter 1 Error!", false, k.IsJinak());
		assertEquals("Constructor Selachimorpha parameter 2 Error!", 1, k.GetKoordinat().GetAbsis());
		assertEquals("Constructor Selachimorpha parameter 3 Error!", 2, k.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testAnimalIntBooleanBooleanBooleanBooleanIntInt() {
		assertEquals("Constructor Animal parameter 1 Error!", 2, k.GetMakanan());
		assertEquals("Constructor Animal parameter 2 Error!", false, k.IsLandAnimal());
		assertEquals("Constructor Animal parameter 3 Error!", true, k.IsWaterAnimal());
		assertEquals("Constructor Animal parameter 4 Error!", false, k.IsAirAnimal());
		assertEquals("Constructor Animal parameter 5 Error!", false, k.IsJinak());
		assertEquals("Constructor Animal parameter 6 Error!", 1, k.GetKoordinat().GetAbsis());
		assertEquals("Constructor Animal parameter 7 Error!", 2, k.GetKoordinat().GetOrdinat());
	}

	@Test
	public void testGetBerat() {
		assertEquals("GetBerat() Error!", 2000, k.GetBerat());
	}
	@Test
	public void testSetBerat() {
		k.SetBerat(1500);
		assertEquals("SetBerat() Error!", 1500, k.GetBerat());
		k.SetBerat(2000);
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("GetKoordinat Absis Error!", 1, k.GetKoordinat().GetAbsis());
		assertEquals("GetKoordinat Ordinat Error!", 2, k.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testSetKooordinat() {
		k.SetKoordinat(3, 4);
		assertEquals("GetKoordinat Absis Error!", 3, k.GetKoordinat().GetAbsis());
		assertEquals("GetKoordinat Ordinat Error!", 4, k.GetKoordinat().GetOrdinat());
		k.SetKoordinat(1, 2);
	}
	
	@Test
	public void testIsLandAnimal() {
		assertEquals("IsLandAnimal() Error!", false, k.IsLandAnimal());
	}

	@Test
	public void testIsWaterAnimal() {
		assertEquals("IsWaterAnimal() Error!", true, k.IsWaterAnimal());
	}

	@Test
	public void testIsAirAnimal() {
		assertEquals("IsAirAinaml() Error!", false, k.IsAirAnimal());
	}

	@Test
	public void testIsJinak() {
		assertEquals("IsJinak() Error!", false, k.IsJinak());
	}

	@Test
	public void testGetMakanan() {
		assertEquals("GetMakanan() Error!", 2, k.GetMakanan());
	}

}