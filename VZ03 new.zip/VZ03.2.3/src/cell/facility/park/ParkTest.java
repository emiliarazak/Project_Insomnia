package cell.facility.park;
import static org.junit.Assert.*;
import org.junit.Test;

import indices.Indices;
/**
*
* @author Emil
*/ 
public class ParkTest {
	private Indices ind = new Indices(5,6);
	private Park p = new Park(ind);
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'P', p.render());
	}
	@Test
	public void testPark() {
		assertEquals("Constructor Park parameter 1 Error!", 5, p.GetKoordinat().GetAbsis());
		assertEquals("Constructor Park parameter 1 Error!", 6, p.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testFacility() {
		assertEquals("Constructor Facility parameter 1 Error!", 5, p.GetKoordinat().GetAbsis());
		assertEquals("Constructor Facility parameter 1 Error!", 6, p.GetKoordinat().GetOrdinat());
		assertEquals("Constructor Facility parameter 2 Error!", true, p.IsPark());
		assertEquals("Constructor Facility parameter 2 Error!", false, p.IsRoad());
		assertEquals("Constructor Facility parameter 2 Error!", false, p.IsRestaurant());
		assertEquals("Constructor Facility parameter 3 Error!", 'p', p.GetCode());
	}
	@Test
	public void testIsRoad() {
		assertEquals("IsRoad() Error!", false, p.IsRoad());
	}
	@Test
	public void testIsPark() {
		assertEquals("IsPark() Error!", true, p.IsPark());
	}
	@Test
	public void testIsRestaurant() {
		assertEquals("IsRetaurant() Error!", false, p.IsRestaurant());
	}
	@Test
	public void testCell() {
		assertEquals("Constructor Cell parameter 1 Error!", 5, p.GetKoordinat().GetAbsis());
		assertEquals("Constructor Cell parameter 1 Error!", 6, p.GetKoordinat().GetOrdinat());
		assertEquals("Constructor Cell parameter 2 Error!", true, p.IsFacility());
		assertEquals("Constructor Cell parameter 2 Error!", false, p.IsHabitat());
		assertEquals("Constructor Cell parameter 3 Error!", 'p', p.GetCode());
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("GetKoordinat() Error!", 5, p.GetKoordinat().GetAbsis());
		assertEquals("GetKoordinat() Error!", 6, p.GetKoordinat().GetOrdinat());
	}
	@Test
	public void testIsHabitat() {
		assertEquals("IsHabitat() Error!", false, p.IsHabitat());
	}
	@Test
	public void testIsFacility() {
		assertEquals("IsFacility() Error!", true, p.IsFacility());
	}
	@Test
	public void testGetCode() {
		assertEquals("GetCode() Error!", 'p', p.GetCode());
	}

}