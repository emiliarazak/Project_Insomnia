/**
 * 
 */

package mainzoo;

import driver.Driver;
import gui.DisplayMenu;

/**Main Class untuk menjalankan Virtual Zoo.
 * @author Luthfi Fadillah
 *
 */

@SuppressWarnings("unused")
public class MainZoo {
  
  /**Main method.
   * @param args Do nothing
   */
  
  public static void main(String[] args) {
    new DisplayMenu();
  }

}