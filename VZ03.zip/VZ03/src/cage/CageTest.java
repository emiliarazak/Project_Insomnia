/**
 * 
 */
package cage;

import static org.junit.Assert.*;

import org.junit.Test;
import indices.Indices;
import animal.Animal;
import animal.carnivora.cheetah.*;

/** Tes untuk kelas cage.
 * 
 * @author Alivia Dewi Parahita
 *
 */
public class CageTest {

  /**
   * Tes metode Constuctor kelas cage .
   */
  @Test
  public void testCageIndicesArrayInt() {
    System.out.println("Constructor");
    
  }

  /**
   * Tes metode copyCage.
   */
  @Test
  public void testCopyCage() {
    System.out.println("copyCage");

  }

  /**
   * Tes metode untuk isHostOf.
   */
  @Test
  public void testIsHostOf() {
    int i;
    System.out.println("isHostOf");
    Indices[] ind;
    ind = new Indices[4];
    for (i=0; i<4; i++) {
      ind[i] = new Indices();
    }
    
    ind[0].setAbsis(0); ind[0].setOrdinat(0);
    ind[1].setAbsis(0); ind[1].setOrdinat(1);
    ind[2].setAbsis(1); ind[2].setOrdinat(0);
    ind[3].setAbsis(1); ind[3].setOrdinat(1);
    
    Cage instance = new Cage(ind,4);
    
    Indices test;
    test = new Indices(4,5);
    
    assertEquals("Salah isHostOf", false, instance.isHostOf(test));
    
  }

  /**
   * Tes metode untuk spacious.
   */
  @Test
  public void testSpacious() {
    int i;
    System.out.println("spacious");
    Indices[] ind;
    ind = new Indices[4];
    for (i=0; i<4; i++) {
      ind[i] = new Indices();
    }
    
    ind[0].setAbsis(0); ind[0].setOrdinat(0);
    ind[1].setAbsis(0); ind[1].setOrdinat(1);
    ind[2].setAbsis(1); ind[2].setOrdinat(0);
    ind[3].setAbsis(1); ind[3].setOrdinat(1);
    
    Cage instance = new Cage(ind,4);
    
    assertEquals("Salah spacious", true, instance.spacious());
  }

  /**
   * Tes metode untuk addAnimal.
   */
  @Test
  public void testAddAnimal() {
    int i;
    System.out.println("addAnimal");
    Indices[] ind;
    ind = new Indices[4];
    for (i=0; i<4; i++) {
      ind[i] = new Indices();
    }
    
    ind[0].setAbsis(0); ind[0].setOrdinat(0);
    ind[1].setAbsis(0); ind[1].setOrdinat(1);
    ind[2].setAbsis(1); ind[2].setOrdinat(0);
    ind[3].setAbsis(1); ind[3].setOrdinat(1);
    
    Cage instance = new Cage(ind,4);
    Cheetah test = new Cheetah(70,0,0);
    instance.addAnimal(test);
    System.out.println(instance.getAnimals()[0].render());
    instance.getAnimals()[0].interact();
    assertEquals("Salah addAnimals", 1, instance.getBanyakHewan());
  }

  /**
   * Tes metod inter.
   * 
   */
  @Test
  public void testInter() {
    System.out.println("inter");
    
  }

  /**
   * Tes metode untuk isCageOf.
   */
  @Test
  public void testIsCageOf() {
    int i;
    System.out.println("isCageOf");
    Indices[] ind;
    ind = new Indices[4];
    for (i=0; i<4; i++) {
      ind[i] = new Indices();
    }
    
    ind[0].setAbsis(0); ind[0].setOrdinat(1);
    ind[1].setAbsis(0); ind[1].setOrdinat(1);
    ind[2].setAbsis(1); ind[2].setOrdinat(0);
    ind[3].setAbsis(1); ind[3].setOrdinat(1);
    
    Cage instance = new Cage(ind,4);
    Cheetah test1 = new Cheetah(70,0,1);
    Cheetah test2 = new Cheetah(70,3,4);
    instance.addAnimal(test1);
    
    assertEquals("Salah isCageOf test 1", true, instance.isCageOf(test1));
    assertEquals("Salah isCageOf test 2", false, instance.isCageOf(test2));
  }

  /**
   * Tes metode getAnimals.
   */
  @Test
  public void testGetAnimals() {
    int i;
    System.out.println("GetAnimal");
    Indices[] ind;
    ind = new Indices[4];
    for (i=0; i<4; i++) {
      ind[i] = new Indices();
    }
    
    ind[0].setAbsis(0); ind[0].setOrdinat(0);
    ind[1].setAbsis(0); ind[1].setOrdinat(1);
    ind[2].setAbsis(1); ind[2].setOrdinat(0);
    ind[3].setAbsis(1); ind[3].setOrdinat(1);
    
    Cage instance = new Cage(ind,4);
    Cheetah test = new Cheetah(70,0,0);
    instance.addAnimal(test);
    
    assertEquals("Salah GetAnimal test render", test.render(), instance.getAnimals()[0].render());
    assertEquals("Salah GetAnimal test berat", test.getBerat(), instance.getAnimals()[0].getBerat());
     
  }

  /**
   * Tes metode getWilayah pada kelas cage.
   */
  @Test
  public void testGetWilayah() {
    int i;
    System.out.println("getWilayah");
    Indices[] ind;
    ind = new Indices[4];
    for (i=0; i<4; i++) {
      ind[i] = new Indices();
    }
    
    ind[0].setAbsis(0); ind[0].setOrdinat(0);
    ind[1].setAbsis(0); ind[1].setOrdinat(1);
    ind[2].setAbsis(1); ind[2].setOrdinat(0);
    ind[3].setAbsis(1); ind[3].setOrdinat(1);
    
    Cage instance = new Cage(ind,4);
    
    assertEquals("Salah wilayah 1 absis", 0, instance.getWilayah()[0].getAbsis());
    assertEquals("Salah wilayah 1 ordinat", 0, instance.getWilayah()[0].getOrdinat());
    assertEquals("Salah wilayah 2 absis", 0, instance.getWilayah()[1].getAbsis());
    assertEquals("Salah wilayah 2 ordinat", 1, instance.getWilayah()[1].getOrdinat());
    assertEquals("Salah wilayah 3 absis", 1, instance.getWilayah()[2].getAbsis());
    assertEquals("Salah wilayah 3 ordinat", 0, instance.getWilayah()[2].getOrdinat());
    assertEquals("Salah wilayah 4 absis", 1, instance.getWilayah()[3].getAbsis());
    assertEquals("Salah wilayah 4 ordinat", 1, instance.getWilayah()[3].getOrdinat());
    
  }

  /**
   * Tes metode getLuas pada kelas cage.
   */
  @Test
  public void testGetLuas() {
    int i;
    System.out.println("getLuas");
    Indices[] ind;
    ind = new Indices[4];
    for (i=0; i<4; i++) {
      ind[i] = new Indices();
    }
    
    ind[0].setAbsis(0); ind[0].setOrdinat(0);
    ind[1].setAbsis(0); ind[1].setOrdinat(1);
    ind[2].setAbsis(1); ind[2].setOrdinat(0);
    ind[3].setAbsis(1); ind[3].setOrdinat(1);
    
    Cage instance = new Cage(ind,4);
    
    assertEquals("Salah luas", 4, instance.getLuas());
  }

  /**
   * Tes metode getBanyakHewan pada kelas cage.
   */
  @Test
  public void testGetBanyakHewan() {
    int i;
    System.out.println("getBanyakHewan");
    Indices[] ind;
    ind = new Indices[4];
    for (i=0; i<4; i++) {
      ind[i] = new Indices();
    }
    
    ind[0].setAbsis(0); ind[0].setOrdinat(0);
    ind[1].setAbsis(0); ind[1].setOrdinat(1);
    ind[2].setAbsis(1); ind[2].setOrdinat(0);
    ind[3].setAbsis(1); ind[3].setOrdinat(1);
    
    Cage instance = new Cage(ind,4);
    
    assertEquals("Salah banyakHewan", 0, instance.getBanyakHewan());
  }

}
