package cage;

/**
 * @author alivia dewi parahita
 * @version 3.0
 * @since 22-03-2017
 */
import animal.Animal;
import animal.animalclone.AnimalClone;
import indices.Indices;

public class Cage {
  //Atribut
    
  /**  Atribut wilayah adalah setiap Indices yang dicakup oleh cage.
   */

  private Indices[] wilayah;
  
  /**  Atribut data_animals adalah daftar hewan yang tinggal dalam cage.
   */
  
  private Animal[] dataAnimal;
  
  /**  Atriubt luas adalah jumlah Indices pada wilayah.
   */
  
  private int luas;

  /**  Atribut banyakHewan adalah jumlah hewan yang tinggal dalam cage.
   */
  
  private int banyakHewan;
    
  private int kapasitas;
    
  //Method
    
  /**  Constructor tanpa parameter dari Cage.
   * Menghidupkan kandang
   */

  public Cage() {}
  
  /**  Constructor dengan parameter dari Cage.
   * Menghidupkan kandang sesuai dengan input parameter
   *
   * @param ind array of Indices menyatakan Cell dengan indices mana saja yang tergabung dalam cage
   * @param neff integer menyatakan banyaknya Indices yang ada pada array
   */
  
  public Cage(Indices[] ind, int neff) {
    int i;
    wilayah = new Indices[neff];
    for (i = 0; i < neff; i++) {
      wilayah[i] = new Indices();
      wilayah[i].copyIndices(ind[i]);
    }
      
    luas = neff;
    banyakHewan = 0;
    kapasitas = (neff * 3) / 10;
    dataAnimal = new Animal[kapasitas];
  }
  
  /** Prosedur copyCage
   * I.S Cage C terdefinisi
   * F.S Menyalin Cage C ke current objek
   * 
   * @param c cage yang ingin dicopy ke current objek
   */
  
  public void copyCage(Cage c) {
    luas = c.luas;
    int i;
    banyakHewan = c.banyakHewan;
    wilayah = new Indices[luas];
    for (i = 0; i < luas; i++) {
      wilayah[i] = new Indices();
      wilayah[i].copyIndices(c.getWilayah()[i]);
    }
      
    dataAnimal = new Animal[banyakHewan];
    for (i = 0; i < banyakHewan; i++) {
      dataAnimal[i].copyAnimal(c.getAnimals()[i]);
    }
  }
  
  /**   Mengembalikan nilai boolean apakah indices termasuk pada cangkupan cage.
   *
   * @param ind adalah indices yang diperiksa sebagai bagian dari cage
   */

  public boolean isHostOf(Indices ind) {
    boolean ketemu = false;
    int i = 0;
    while ((i < luas) && (!ketemu)) {
      ketemu = (ind.isEqual(wilayah[i]));
      i++;
    }
    return ketemu;
  }
  
  /**  Mengembalikan nilai boolean apakah masih ada ruang untuk animal di cage tersebut.
   */
  
  public boolean spacious() {
    return (banyakHewan < kapasitas);
  }
  
  /**  Prosedur addAnimal dari Cage.
   * I.S Cage telah hidup dan Masukkan terdefinisi sebagai hewan yang hidup
   * F.S Animal A tercatat pada Data Animals Cage
   * Menambahkan Animals A pada Data Animals Cage
   *
   * @param a adalah Pointer to Animals yang ingin dimasukkan di Data Animals
   */
  
  public void addAnimal(Animal a) {
    Indices ind;
    ind = new Indices();
    ind.copyIndices(a.getKoordinat());
    if (isHostOf(ind)) {
      if (spacious()) {
        if (!(a.isJinak())) {
          if (banyakHewan == 0) {
            banyakHewan++;
            dataAnimal[banyakHewan - 1] = new AnimalClone(a.render(), a.getInteraction());
            dataAnimal[banyakHewan - 1].copyAnimal(a);
          } else {
            if (a.render() == getAnimals()[0].render()) {
              banyakHewan++;
              dataAnimal[banyakHewan - 1] = new AnimalClone(a.render(), a.getInteraction());
              dataAnimal[banyakHewan - 1].copyAnimal(a);
            }
          }
        } else {
          banyakHewan++;
          dataAnimal[banyakHewan - 1] = new AnimalClone(a.render(), a.getInteraction());
          dataAnimal[banyakHewan - 1].copyAnimal(a);
        }
      }
    }
  }
  
  /**  Prosedur inter dari Cage
   * I.S Cage terdefinisi
   * F.S Memanggil semua prosedur interact dari animals yang ada di Cage
   * Mencetak semua suara binatang yang ada dalam kandang
   */
  
  public void inter() {
    for (int i = 0; i < banyakHewan; i++) {
      dataAnimal[i].interact();
    }
  }
  
  /**  Mengembalikan nilai boolean apakah animals tinggal di kandang tersebut.
   *
   * @param a adalah Pointer to Animals yang diperiksa
   */
  
  public boolean isCageOf(Animal a) {
    int i = 0;
    boolean ketemu = false;
    while (!ketemu && (i < banyakHewan)) {
      ketemu = dataAnimal[i].isEqual(a);
      i++;
    }
    return ketemu;
  }

  /**  Mengembalikan nilai atribut DataAnimals.
   */
  
  public Animal[] getAnimals() {
    return dataAnimal;
  }
  
  /**  Mengembalikan nilai atribut wilayah.
   */
  
  public Indices[] getWilayah() {
    return wilayah;
  }
  
  /**  getLuas dari cage.
   * Mengembalikan nilai luas suatu kandang
   */
  
  public int getLuas() {
    return luas;
  }
  
  /**  getBanyakHewan dari Cage.
   * Mengembalikan nilai banyaknya hewan yang ada di suatu kandang
   */
  
  public int getBanyakHewan() {
    return banyakHewan;
  }

}