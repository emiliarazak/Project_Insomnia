package renderable;

/**Interface Renderable.
 * @author Luthfi Fadillah
 * 
 */

public interface Renderable {
  /** Virtual method Render untuk mengembalikan kode renderable.
   * @return char : Mengembalikan kode renderable.
   */
  char render();

}