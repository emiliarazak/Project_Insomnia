/**
 * 
 */

package indices;

/** Class Indices.
 * @author suzaneringoringo
 *
 */

public final class Indices {

  /** Attribut x adalah nilai absis indeks.
   */

  protected int absis;
  
  /** Attribut y adalah nilai ordinat indeks.
   */
  
  protected int ordinat;
  
  /** Constructor tanpa parameter dari indices.
   * Menghidupkan indeks
   */

  public Indices() {
    absis = 0;
    ordinat = 0;
  }
  
  /** Constructor dengan parameter dari indices.
   * Menghidupkan indeks sesuai parameter
   *
   * @param absis integer adalah absis yang akan di set
   * @param ordinat integer adalah ordinat yang akan di set
   */
  
  public Indices(int absis, int ordinat) {
    this.absis = absis;
    this.ordinat = ordinat;
  }
  
  /** Operator overloading = dari indices.
   * Memastikan bukan bitewise copy
   *
   * @param ind menyatakan indices yang ingin disalin
   */
  
  public void copyIndices(Indices ind) {
    absis = ind.getAbsis();
    ordinat = ind.getOrdinat();
  }
  
  /** getAbsis dari indices.
   * Mengembalikan nilai absis dari indeks
   *
   */
  
  public int getAbsis() {
    return absis;
  }
  
  /** getOrdinat dari indices.
   * Mengembalikan nilai ordinat dari indeks
   *
   */
  
  public int getOrdinat() {
    return ordinat;
  }
  
  /** Prosedur setAbsis dari indices.
   * I.S indices sudah hidup dan masukan terdefinisi
   * F.S Absis indices nilai menjadi masukan
   *
   * @param x integer adalah nilai absis yang akan di set
   */
  
  public void setAbsis(int x) {
    this.absis = x;
  }
  
  /** Prosedur setOrdinat dari indices.
   * I.S indices sudah hidup dan masukan terdefinisi
   * F.S Ordinat indices nilai menjadi masukan
   *
   * @param y integer adalah nilai ordinat yang akan di set
   */
  
  public void setOrdinat(int y) {
    this.ordinat = y;
  }
  
  /** Mengembalikan nilai booleanean apakah indices masukan sama dengan current objek.
   *
   * @param ind indices yang ingin dibandingkan dengan current objek
   */
  
  public boolean isEqual(Indices ind) {
    return ((this.absis == ind.getAbsis()) && (this.ordinat == ind.getOrdinat()));
  }
  
  public void printKoordinat() {
    System.out.println("(" + absis + ", " + ordinat + ")");
  }
}