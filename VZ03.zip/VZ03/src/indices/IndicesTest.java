package indices;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import indices.Indices;

public class IndicesTest {
	  
	  public IndicesTest() {
	  }
	  
	  @BeforeClass
	  public static void setUpClass() {
	  }
	  
	  @AfterClass
	  public static void tearDownClass() {
	  }

	  /**
	   * Test of Copy method, of class indices.
	   */
	  @Test
	  public void testCopyIndices() {
	    System.out.println("Copy");
	    Indices ind = new Indices(1,1);
	    Indices instance = new Indices();
	    instance.copyIndices(ind);
	    assertEquals(instance.getAbsis(), 1);
	    assertEquals(instance.getOrdinat(), 1);
	  }

	  /**
	   * Test of getAbsis method, of class indices.
	   */
	  @Test
	  public void testGetAbsis() {
	    System.out.println("getAbsis");
	    Indices instance = new Indices(3,3);
	    int expResult = 3;
	    int result = instance.getAbsis();
	    assertEquals(expResult, result);
	  }

	  /**
	   * Test of getOrdinat method, of class indices.
	   */
	  @Test
	  public void testGetOrdinat() {
	    System.out.println("getOrdinat");
	    Indices instance = new Indices(4,4);
	    int expResult = 4;
	    int result = instance.getOrdinat();
	    assertEquals(expResult, result);
	  }

	  /**
	   * Test of setAbsis method, of class indices.
	   */
	  @Test
	  public void testSetAbsis() {
	    System.out.println("setAbsis");
	    int x = 0;
	    Indices instance = new Indices(1,1);
	    instance.setAbsis(x);
	    assertEquals(instance.getAbsis(), x);
	  }

	  /**
	   * Test of setOrdinat method, of class indices.
	   */
	  @Test
	  public void testSetOrdinat() {
	    System.out.println("setOrdinat");
	    int y = 0;
	    Indices instance = new Indices(1,1);
	    instance.setOrdinat(y);
	    assertEquals(instance.getOrdinat(), y);
	  }

	  /**
	   * Test of isEqual method, of class indices.
	   */
	  @Test
	  public void testIsEqual() {
	    System.out.println("isEqual");
	    Indices ind = new Indices(0,1);
	    Indices instance = new Indices(1,0);
	    boolean expResult = false;
	    boolean result = instance.isEqual(ind);
	    assertEquals(expResult, result);
	  }

	  /**
	   * Test of printKoordinat method, of class indices.
	   */
	  @Test
	  public void testPrintKoordinat() {
	    System.out.println("printKoordinat");
	    Indices instance = new Indices(7,7);
	    instance.printKoordinat();
	  }
	  
}
