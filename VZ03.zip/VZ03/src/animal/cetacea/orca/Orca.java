/**
 * 
 */

package animal.cetacea.orca;

import animal.cetacea.Cetacea;
import renderable.Renderable;

/**Real Class Orca.
 * @author Luthfi Fadillah
 *
 */

public class Orca extends Cetacea implements Renderable {
  /** Constructor dari Orca.
   * Menghidupkan hewan Orca.
   *
   * @param x : bertipe int, adalah letak absis Orca yang dihidupkan.
   * @param y : bertipe int, adalah letak ordinat Orca yang dihidupkan.
   * @param bb : bertipe int, adalah berat badan Orca yang dihidupkan.
   */
  
  public Orca(int bb, int x, int y) {
    super(false, x, y);
    setBerat(bb);
    setInteraction("*WWUSHHHO");
  }
  
  /** Mengembalikan nilai character kode dari objek Orca.
   * @return char : kode yang nantinya siap dicetak ke layar.
   */
  
  public char render() {
    return '$';
  }
}