/**
 * 
 */

package animal.primates.gorilla;

import animal.primates.Primates;

/** Kelas spesies Gorilla.
 * 
 * @author Suzane Ringoringo
 *
 */
public final class Gorilla extends Primates {
  /** Constructor dari Gorilla.
   * Menghidupkan hewan Gorilla
   *
   * @param x integer adalah letak absis Gorilla yang dihidupkan
   * @param y integer adalah letak ordinat Gorilla yang dihidupkan
   * @param bb integer adalah berat badan Gorilla yang dihidupkan
   */
  public Gorilla(int bb, int x, int y) {
    super(true, x, y);
    setBerat(bb);
    setInteraction("UUUAAAA");
  }
  
  @Override
  /** fungsi Render dari objek Gorilla
    * Mengembalikan kode Gorilla pada layar
    * 
    * @return char
    */
  public char render() {
    return 'J';
  }
}
