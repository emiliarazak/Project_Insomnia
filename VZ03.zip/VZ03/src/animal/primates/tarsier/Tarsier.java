/**
 * 
 */

package animal.primates.tarsier;

import animal.primates.Primates;

/** Kelas spesies Tarsier.
 * 
 * @author Suzane Ringoringo
 *
 */
public final class Tarsier extends Primates {
  /** Constructor dari Tarsier.
   * Menghidupkan hewan Tarsier
   *
   * @param x integer adalah letak absis Tarsier yang dihidupkan
   * @param y integer adalah letak ordinat Tarsier yang dihidupkan
   * @param bb integer adalah berat badan Tarsier yang dihidupkan
   */
  public Tarsier(int bb, int x, int y) {
    super(true, x, y);
    setBerat(bb);
    setInteraction("*big cute eyes");
  }
  
  @Override
  /** fungsi Render dari objek Tarsier
    * Mengembalikan kode Tarsier pada layar
    * 
    * @return char
    */
  public char render() {
    return 'F';
  }
}
