/**
 * 
 */

package animal.primates.monkey;

import animal.primates.Primates;

/** Kelas spesies Monkey.
 * 
 * @author Suzane Ringoringo
 *
 */
public final class Monkey extends Primates {
  /** Constructor dari Monkey.
   * Menghidupkan hewan Monkey
   *
   * @param x integer adalah letak absis Monkey yang dihidupkan
   * @param y integer adalah letak ordinat Monkey yang dihidupkan
   * @param bb integer adalah berat badan Monkey yang dihidupkan
   */
  public Monkey(int bb, int x, int y) {
    super(true, x, y);
    setBerat(bb);
    setInteraction("U u a a");
  }
 
  @Override
  /** fungsi Render dari objek Monkey
    * Mengembalikan kode Monkey pada layar
    * 
    * @return char
    */
  public char render() {
    return 'Y';
  }
}
