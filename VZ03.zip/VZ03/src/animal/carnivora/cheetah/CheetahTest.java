/**
 * 
 */
package animal.carnivora.cheetah;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.*;

/**
 * @author Suzane Ringoringo
 *
 */
public class CheetahTest {
	private Cheetah x = new Cheetah(65,1,2);
	
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

	@Before
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	}

	@After
	public void cleanUpStreams() {
	    System.setOut(null);
	}
	
	/**
	 * Test method for {@link animal.carnivora.cheetah.Cheetah#interact()}.
	 */
	@Test
	public void testInteract() {
		x.interact();
	    assertEquals("interact() Error!","*runs so swiftly*\n", outContent.toString());
	}

	/**
	 * Test method for {@link animal.carnivora.cheetah.Cheetah#Cheetah(int, int, int)}.
	 */
	@Test
	public void testCheetah() {
	    assertEquals("Constructor Cheetah parameter 1 Error!", 65, x.getBerat());
	    assertEquals("Constructor Cheetah parameter 2 Error!", 1, x.getKoordinat().getAbsis());
	    assertEquals("Constructor Cheetah parameter 3 Error!", 2, x.getKoordinat().getOrdinat());
	}

	/**
	 * Test method for {@link animal.carnivora.cheetah.Cheetah#render()}.
	 */
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'T', x.render());
	}

	/**
	 * Test method for {@link animal.carnivora.carnivora#carnivora(boolean, int, int)}.
	 */
	@Test
	public void testCarnivora() {
		assertEquals("Constructor Carnivora parameter 1 Error!", false, x.isJinak());
	    assertEquals("Constructor Carnivora parameter 2 Error!", 1, x.getKoordinat().getAbsis());
	    assertEquals("Constructor Carnivora parameter 3 Error!", 2, x.getKoordinat().getOrdinat());
	}

	/**
	 * Test method for {@link animal.Animal#Animal(int, boolean, boolean, boolean, boolean, int, int)}.
	 */
	@Test
	public void testAnimalConstructorWithParameter() {
		assertEquals("Constructor Animal parameter 1 Error!", 2, x.getMakanan());
	    assertEquals("Constructor Animal parameter 2 Error!", true, x.isLandAnimal());
	    assertEquals("Constructor Animal parameter 3 Error!", false, x.isWaterAnimal());
		assertEquals("Constructor Animal parameter 4 Error!", false, x.isAirAnimal());
		assertEquals("Constructor Animal parameter 5 Error!", false, x.isJinak());
	    assertEquals("Constructor Animal parameter 6 Error!", 1, x.getKoordinat().getAbsis());
	    assertEquals("Constructor Animal parameter 7 Error!", 2, x.getKoordinat().getOrdinat());
	}

	/**
	 * Test method for {@link animal.Animal#getBerat()}.
	 */
	@Test
	public void testGetBerat() {
	    assertEquals("getBerat() Error!", 65, x.getBerat());
	}

	/**
	 * Test method for {@link animal.Animal#setBerat(int)}.
	 */
	@Test
	public void testSetBerat() {
		x.setBerat(7);
	    assertEquals("setBerat() Error!", 7, x.getBerat());
		x.setBerat(65);
	}

	/**
	 * Test method for {@link animal.Animal#getKoordinat()}.
	 */
	@Test
	public void testGetKoordinat() {
	    assertEquals("getKoordinat Absis Error!", 1, x.getKoordinat().getAbsis());
	    assertEquals("getKoordinat Ordinat Error!", 2, x.getKoordinat().getOrdinat());		
	}

	/**
	 * Test method for {@link animal.Animal#setKoordinat(int, int)}.
	 */
	@Test
	public void testSetKoordinat() {
		x.setKoordinat(3, 4);
	    assertEquals("setKoordinat Absis Error!", 3, x.getKoordinat().getAbsis());
	    assertEquals("setKoordinat Ordinat Error!", 4, x.getKoordinat().getOrdinat());
	    x.setKoordinat(1, 2);
	}

	/**
	 * Test method for {@link animal.Animal#isLandAnimal()}.
	 */
	@Test
	public void testIsLandAnimal() {
	    assertEquals("isLandAnimal() Error!", true, x.isLandAnimal());
	}

	/**
	 * Test method for {@link animal.Animal#isWaterAnimal()}.
	 */
	@Test
	public void testIsWaterAnimal() {
	    assertEquals("isWaterAnimal() Error!", false, x.isWaterAnimal());
	}

	/**
	 * Test method for {@link animal.Animal#isAirAnimal()}.
	 */
	@Test
	public void testIsAirAnimal() {
		assertEquals("isAirAnimal() Error!", false, x.isAirAnimal());
	}

	/**
	 * Test method for {@link animal.Animal#isJinak()}.
	 */
	@Test
	public void testIsJinak() {
		assertEquals("isJinak() Error!", false, x.isJinak());
	}

	/**
	 * Test method for {@link animal.Animal#getMakanan()}.
	 */
	@Test
	public void testGetMakanan() {
		assertEquals("getMakanan() Error!", 2, x.getMakanan());
	}

	/**
	 * Test method for {@link animal.Animal#copyAnimal(animal.Animal)}.
	 */
	@Test
	public void testCopyAnimal() {
		Cheetah y = new Cheetah(66,2,3);
		y.copyAnimal(x);
		assertEquals("copyAnimal() Error!", 2, y.getMakanan());
	    assertEquals("copyAnimal() Error!", true, y.isLandAnimal());
	    assertEquals("copyAnimal() Error!", false, y.isWaterAnimal());
		assertEquals("copyAnimal() Error!", false, y.isAirAnimal());
		assertEquals("copyAnimal() Error!", false, y.isJinak());
	    assertEquals("copyAnimal() Error!", 1, y.getKoordinat().getAbsis());
	    assertEquals("copyAnimal() Error!", 2, y.getKoordinat().getOrdinat());
	    assertEquals("copyAnimal() Error!", 65, y.getBerat());
	}

}