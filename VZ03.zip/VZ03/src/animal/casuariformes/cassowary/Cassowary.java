package animal.casuariformes.cassowary;

import animal.casuariformes.Casuariformes;

/** Kelas spesies Cassowary.
 * 
 * @author Alivia Dewi Parahita
 *
 */
public final class Cassowary extends Casuariformes {
  /** Constructor dari Cassowary.
   * Menghidupkan hewan Cassowary
   *
   * @param x integer adalah letak absis Cassowary yang dihidupkan
   * @param y integer adalah letak ordinat Cassowary yang dihidupkan
   * @param bb integer adalah berat badan Cassowary yang dihidupkan
   */
  public Cassowary(int bb, int x, int y) {
    super(true, x, y);
    setBerat(bb);
    setInteraction("I can't fly :(");
  }
  
  @Override
  /** fungsi Render dari objek Cassowary
    * Mengembalikan kode Cassowary pada layar
    * 
    * @return char
    */
  public char render() {
    return 'C';
  }
}