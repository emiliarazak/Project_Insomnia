package animal.anseriformes.duck;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
*
* @author Emil
*/ 
public class DuckTest {
  private Duck u = new Duck(3,1,2);
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	@Before
	public void setUpStreams() {
		System.setOut(new PrintStream(outContent));
	}
	@After
	public void cleanUpStreams() {
		System.setOut(null);
	}
	@Test
	public void testInteract() {
		u.interact();
		assertEquals("interact() Error!", "Qwekk qwekk\n", outContent.toString());
	}
	@Test
	public void testDuck() {
		assertEquals("Constructor Duck parameter 1 Error!", 3, u.getBerat());
		assertEquals("Constructor Duck parameter 2 Error!", 1, u.getKoordinat().getAbsis());
		assertEquals("Constructor Duck parameter 3 Error!", 2, u.getKoordinat().getOrdinat());
	}
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'U', u.render());
	}

	@Test
	public void testAnseriformes() {
		assertEquals("Constructor Anseriformes parameter 1 Error!", true, u.isJinak());
		assertEquals("Constructor Anseriformes parameter 2 Error!", 1, u.getKoordinat().getAbsis());
		assertEquals("Constructor Anseriformes parameter 3 Error!", 2, u.getKoordinat().getOrdinat());
	}
	@Test
	public void testAnimalIntBooleanBooleanBooleanBooleanIntInt() {
		assertEquals("Constructor Animal parameter 1 Error!", 1, u.getMakanan());
		assertEquals("Constructor Animal parameter 2 Error!", true, u.isLandAnimal());
		assertEquals("Constructor Animal parameter 3 Error!", true, u.isWaterAnimal());
		assertEquals("Constructor Animal parameter 4 Error!", false, u.isAirAnimal());
		assertEquals("Constructor Animal parameter 5 Error!", true, u.isJinak());
		assertEquals("Constructor Animal parameter 6 Error!", 1, u.getKoordinat().getAbsis());
		assertEquals("Constructor Animal parameter 7 Error!", 2, u.getKoordinat().getOrdinat());
	}
	@Test
	public void testGetBerat() {
		assertEquals("getBerat() Error!", 3, u.getBerat());
	}
	@Test
	public void testSetBerat() {
		u.setBerat(2);
		assertEquals("setBerat() Error!", 2, u.getBerat());
		u.setBerat(3);
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("getKoordinat Absis Error!", 1, u.getKoordinat().getAbsis());
		assertEquals("getKoordinat Ordinat Error!", 2, u.getKoordinat().getOrdinat());
	}

	@Test
	public void testSetKoordinat() {
		u.setKoordinat(3, 4);
		assertEquals("getKoordinat Absis Error!", 3, u.getKoordinat().getAbsis());
		assertEquals("getKoordinat Ordinat Error!", 4, u.getKoordinat().getOrdinat());
		u.setKoordinat(1, 2);
	}

	@Test
	public void testIsLandAnimal() {
		assertEquals("isLandAnimal() Error!", true, u.isLandAnimal());
	}

	@Test
	public void testIsWaterAnimal() {
		assertEquals("isWaterAnimal() Error!", true, u.isWaterAnimal());
	}

	@Test
	public void testIsAirAnimal() {
		assertEquals("isAirAnimal() Error!", false, u.isAirAnimal());
	}
	@Test
	public void testIsJinak() {
		assertEquals("isJinak() Error!", true , u.isJinak());
	}

	@Test
	public void testGetMakanan() {
		assertEquals("getMakanan() Error!", 1, u.getMakanan());
	}
}