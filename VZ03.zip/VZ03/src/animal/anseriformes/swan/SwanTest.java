package animal.anseriformes.swan;
import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SwanTest {
	private Swan q = new Swan(12,1,2);
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	@Before
	public void setUpStreams() {
		System.setOut(new PrintStream(outContent));
	}
	@After
	public void cleanUpStreams() {
		System.setOut(null);
	}
	@Test
	public void testInteract() {
		q.interact();
		assertEquals("interact() Error!", "Qwokk qwokk\n", outContent.toString());
	}

	@Test
	public void testSwan() {
		assertEquals("Constructor Swan parameter 1 Error!", 12, q.getBerat());
		assertEquals("Constructor Swan parameter 2 Error!", 1, q.getKoordinat().getAbsis());
		assertEquals("Constructor Swan parameter 3 Error!", 2, q.getKoordinat().getOrdinat());
	}

	@Test
	public void testRender() {
		assertEquals("render() Error!", 'Q', q.render());
	}

	@Test
	public void testAnseriformes() {
		assertEquals("Constructor Anseriformes parameter 1 Error!", true, q.isJinak());
		assertEquals("Constructor Anseriformes parameter 2 Error!", 1, q.getKoordinat().getAbsis());
		assertEquals("Constructor Anseriformes parameter 3 Error!", 2, q.getKoordinat().getOrdinat());
	}
	@Test
	public void testAnimalIntBooleanBooleanBooleanBooleanIntInt() {
		assertEquals("Constructor Animal parameter 1 Error!", 1, q.getMakanan());
		assertEquals("Constructor Animal parameter 2 Error!", true, q.isLandAnimal());
		assertEquals("Constructor Animal parameter 3 Error!", true, q.isWaterAnimal());
		assertEquals("Constructor Animal parameter 4 Error!", false, q.isAirAnimal());
		assertEquals("Constructor Animal parameter 5 Error!", true, q.isJinak());
		assertEquals("Constructor Animal parameter 6 Error!", 1, q.getKoordinat().getAbsis());
		assertEquals("Constructor Animal parameter 7 Error!", 2, q.getKoordinat().getOrdinat());
	}
	@Test
	public void testGetBerat() {
		assertEquals("getBerat() Error!", 12, q.getBerat());
	}
	@Test
	public void testSetBerat() {
		q.setBerat(13);
		assertEquals("getBerat() Error!", 13, q.getBerat());
		q.setBerat(12);
	}

	@Test
	public void testGetKoordinat() {
		assertEquals("getKoordinat Absis Error!", 1, q.getKoordinat().getAbsis());
		assertEquals("getKoordinat Ordinat Error!", 2, q.getKoordinat().getOrdinat());
	}

	@Test
	public void testSetKoordinat() {
		q.setKoordinat(3, 4);
		assertEquals("getKoordinat Absis Error!", 3, q.getKoordinat().getAbsis());
		assertEquals("getKoordinat Ordinat Error!", 4, q.getKoordinat().getOrdinat());
		q.setKoordinat(1, 2);
	}

	@Test
	public void testIsLandAnimal() {
		assertEquals("isLandAnimal() Error!", true, q.isLandAnimal());
	}

	@Test
	public void testIsWaterAnimal() {
		assertEquals("isWaterAnimal() Error!", true, q.isWaterAnimal());
	}

	@Test
	public void testIsAirAnimal() {
		assertEquals("isAirAnimal() Error!", false, q.isAirAnimal());
	}

	@Test
	public void testIsJinak() {
		assertEquals("isJinak() Error!", true , q.isJinak());
	}

	@Test
	public void testGetMakanan() {
		assertEquals("getMakanan() Error!", 1, q.getMakanan());
	}
}