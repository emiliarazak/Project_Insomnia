/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package animal.selachimorpha;

import animal.Animal;

/** Abstract Class Selachimorpha.
*
* @author Emil
*/
public abstract class Selachimorpha extends Animal {
  /** Constructor dari Selachimorpha.
   * Menghidupkan hewan Ordo Selachimorpha
   *
   * @param x integer adalah letak absis Selachimorpha yang dihidupkan
   * @param y integer adalah letak ordinat Selachimorpha yang dihidupkan
   * @param kejinakan boolean menyatakan jinak tidaknya hewan
   */    
  public Selachimorpha(boolean kejinakan, int x, int y) {
    super(2, false, true, false, kejinakan, x, y);
  }
}