/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package animal.selachimorpha.greatwhiteshark;

import animal.selachimorpha.Selachimorpha;
import renderable.Renderable;

/** Real Class GreatWhiteShark.
*
* @author Emil
*/
public class GreatWhiteShark extends Selachimorpha implements Renderable {
  /** Constructor dari GreatWhiteShark.
   * Menghidupkan hewan GreatWhiteShark
   *
   * @param x integer adalah letak absis GreatWhiteShark yang dihidupkan
   * @param y integer adalah letak ordinat GreatWhiteShark yang dihidupkan
   * @param bb integer adalah berat badan GreatWhiteShark yang dihidupkan
   */
 
  public GreatWhiteShark(int bb, int x, int y) {
    super(false, x, y);
    setBerat(bb);
    setInteraction("*Big grins* heyyo");
  }
 
  /** Mengembalikan nilai character kode dari objek GreatWhiteShark.
   * Character ini nantinya yang siap dicetak ke layar
   */

  public char render() {
    return 'K';
  }
}