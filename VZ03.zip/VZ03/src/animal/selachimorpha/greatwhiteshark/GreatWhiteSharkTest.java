package animal.selachimorpha.greatwhiteshark;
import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
/**
*
* @author Emil
*/ 
public class GreatWhiteSharkTest {
	private GreatWhiteShark k = new GreatWhiteShark(2000,1,2);
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	
	@Before
	public void setUpStreams() {
		System.setOut(new PrintStream(outContent));
	}
	@After
	public void cleanUpStreams() {
		System.setOut(null);
	}
	@Test
	public void testInteract() {
		k.interact();
		assertEquals("interact() Error!", "*Big grins* heyyo\n", outContent.toString());
	}
	@Test
	public void testGreatWhiteShark() {
		assertEquals("Constructor GreatWhiteShark parameter 1 Error!", 2000, k.getBerat());
		assertEquals("Constructor GreatWhiteShark parameter 2 Error!", 1, k.getKoordinat().getAbsis());
		assertEquals("Constructor GreatWhiteShark parameter 3 Error!", 2, k.getKoordinat().getOrdinat());
	}
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'K', k.render());
	}
	@Test
	public void testSelachimorpha() {
		assertEquals("Constructor Selachimorpha parameter 1 Error!", false, k.isJinak());
		assertEquals("Constructor Selachimorpha parameter 2 Error!", 1, k.getKoordinat().getAbsis());
		assertEquals("Constructor Selachimorpha parameter 3 Error!", 2, k.getKoordinat().getOrdinat());
	}
	@Test
	public void testAnimalIntBooleanBooleanBooleanBooleanIntInt() {
		assertEquals("Constructor Animal parameter 1 Error!", 2, k.getMakanan());
		assertEquals("Constructor Animal parameter 2 Error!", false, k.isLandAnimal());
		assertEquals("Constructor Animal parameter 3 Error!", true, k.isWaterAnimal());
		assertEquals("Constructor Animal parameter 4 Error!", false, k.isAirAnimal());
		assertEquals("Constructor Animal parameter 5 Error!", false, k.isJinak());
		assertEquals("Constructor Animal parameter 6 Error!", 1, k.getKoordinat().getAbsis());
		assertEquals("Constructor Animal parameter 7 Error!", 2, k.getKoordinat().getOrdinat());
	}

	@Test
	public void testGetBerat() {
		assertEquals("getBerat() Error!", 2000, k.getBerat());
	}
	@Test
	public void testSetBerat() {
		k.setBerat(1500);
		assertEquals("setBerat() Error!", 1500, k.getBerat());
		k.setBerat(2000);
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("getKoordinat Absis Error!", 1, k.getKoordinat().getAbsis());
		assertEquals("getKoordinat Ordinat Error!", 2, k.getKoordinat().getOrdinat());
	}
	@Test
	public void testSetKooordinat() {
		k.setKoordinat(3, 4);
		assertEquals("getKoordinat Absis Error!", 3, k.getKoordinat().getAbsis());
		assertEquals("getKoordinat Ordinat Error!", 4, k.getKoordinat().getOrdinat());
		k.setKoordinat(1, 2);
	}
	
	@Test
	public void testIsLandAnimal() {
		assertEquals("isLandAnimal() Error!", false, k.isLandAnimal());
	}

	@Test
	public void testIsWaterAnimal() {
		assertEquals("isWaterAnimal() Error!", true, k.isWaterAnimal());
	}

	@Test
	public void testIsAirAnimal() {
		assertEquals("IsAirAinaml() Error!", false, k.isAirAnimal());
	}

	@Test
	public void testIsJinak() {
		assertEquals("isJinak() Error!", false, k.isJinak());
	}

	@Test
	public void testGetMakanan() {
		assertEquals("getMakanan() Error!", 2, k.getMakanan());
	}

}