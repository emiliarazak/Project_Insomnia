/**
 * 
 */
package animal.artiodactyls.giraffe;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.*;


/**
 * @author luthfi_fadillah
 *
 */
public class GiraffeTest {
	private Giraffe x = new Giraffe(30,1,2);
	
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

	@Before
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	}

	@After
	public void cleanUpStreams() {
	    System.setOut(null);
	}
	
	/**
	 * Test method for {@link animal.artiodactyls.Giraffe.Giraffe#interact()}.
	 */
	@Test
	public void testInteract() {
		x.interact();
	    assertEquals("interact() Error!","where are u? i cant see you! are you down there?? please come up!\n", outContent.toString());
	}

	/**
	 * Test method for {@link animal.artiodactyls.Giraffe.Giraffe#Giraffe(int, int, int)}.
	 */
	@Test
	public void testGiraffe() {
	    assertEquals("Constructor Giraffe parameter 1 Error!", 30, x.getBerat());
	    assertEquals("Constructor Giraffe parameter 2 Error!", 1, x.getKoordinat().getAbsis());
	    assertEquals("Constructor Giraffe parameter 3 Error!", 2, x.getKoordinat().getOrdinat());
	}

	/**
	 * Test method for {@link animal.artiodactyls.Giraffe.Giraffe#render()}.
	 */
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'G', x.render());
	}

	/**
	 * Test method for {@link animal.artiodactyls.Artiodactyls#Artiodactyls(boolean, int, int)}.
	 */
	@Test
	public void testArtiodactyls() {
		assertEquals("Constructor Artiodactyls parameter 1 Error!", true, x.isJinak());
	    assertEquals("Constructor Artiodactyls parameter 2 Error!", 1, x.getKoordinat().getAbsis());
	    assertEquals("Constructor Artiodactyls parameter 3 Error!", 2, x.getKoordinat().getOrdinat());
	}

	/**
	 * Test method for {@link animal.Animal#Animal(int, boolean, boolean, boolean, boolean, int, int)}.
	 */
	@Test
	public void testAnimalConstructorWithParameter() {
		assertEquals("Constructor Animal parameter 1 Error!", 0, x.getMakanan());
	    assertEquals("Constructor Animal parameter 2 Error!", true, x.isLandAnimal());
	    assertEquals("Constructor Animal parameter 3 Error!", false, x.isWaterAnimal());
		assertEquals("Constructor Animal parameter 4 Error!", false, x.isAirAnimal());
		assertEquals("Constructor Animal parameter 5 Error!", true, x.isJinak());
	    assertEquals("Constructor Animal parameter 6 Error!", 1, x.getKoordinat().getAbsis());
	    assertEquals("Constructor Animal parameter 7 Error!", 2, x.getKoordinat().getOrdinat());
	}

	/**
	 * Test method for {@link animal.Animal#getBerat()}.
	 */
	@Test
	public void testGetBerat() {
	    assertEquals("getBerat() Error!", 30, x.getBerat());
	}

	/**
	 * Test method for {@link animal.Animal#setBerat(int)}.
	 */
	@Test
	public void testSetBerat() {
		x.setBerat(50);
	    assertEquals("setBerat() Error!", 50, x.getBerat());
		x.setBerat(30);
	}

	/**
	 * Test method for {@link animal.Animal#getKoordinat()}.
	 */
	@Test
	public void testGetKoordinat() {
	    assertEquals("getKoordinat Absis Error!", 1, x.getKoordinat().getAbsis());
	    assertEquals("getKoordinat Ordinat Error!", 2, x.getKoordinat().getOrdinat());		
	}

	/**
	 * Test method for {@link animal.Animal#setKoordinat(int, int)}.
	 */
	@Test
	public void testSetKoordinat() {
		x.setKoordinat(3, 4);
	    assertEquals("setKoordinat Absis Error!", 3, x.getKoordinat().getAbsis());
	    assertEquals("setKoordinat Ordinat Error!", 4, x.getKoordinat().getOrdinat());
	    x.setKoordinat(1, 2);
	}

	/**
	 * Test method for {@link animal.Animal#isLandAnimal()}.
	 */
	@Test
	public void testIsLandAnimal() {
	    assertEquals("isLandAnimal() Error!", true, x.isLandAnimal());
	}

	/**
	 * Test method for {@link animal.Animal#isWaterAnimal()}.
	 */
	@Test
	public void testIsWaterAnimal() {
	    assertEquals("isWaterAnimal() Error!", false, x.isWaterAnimal());
	}

	/**
	 * Test method for {@link animal.Animal#isAirAnimal()}.
	 */
	@Test
	public void testIsAirAnimal() {
		assertEquals("isAirAnimal() Error!", false, x.isAirAnimal());
	}

	/**
	 * Test method for {@link animal.Animal#isJinak()}.
	 */
	@Test
	public void testIsJinak() {
		assertEquals("isJinak() Error!", true, x.isJinak());
	}

	/**
	 * Test method for {@link animal.Animal#getMakanan()}.
	 */
	@Test
	public void testGetMakanan() {
		assertEquals("getMakanan() Error!", 0, x.getMakanan());
	}

	/**
	 * Test method for {@link animal.Animal#copyAnimal(animal.Animal)}.
	 */
	@Test
	public void testCopyAnimal() {
		Giraffe y = new Giraffe(40,2,3);
		y.copyAnimal(x);
		assertEquals("copyAnimal() Error!", 0, y.getMakanan());
	    assertEquals("copyAnimal() Error!", true, y.isLandAnimal());
	    assertEquals("copyAnimal() Error!", false, y.isWaterAnimal());
		assertEquals("copyAnimal() Error!", false, y.isAirAnimal());
		assertEquals("copyAnimal() Error!", true, y.isJinak());
	    assertEquals("copyAnimal() Error!", 1, y.getKoordinat().getAbsis());
	    assertEquals("copyAnimal() Error!", 2, y.getKoordinat().getOrdinat());
	    assertEquals("copyAnimal() Error!", 30, y.getBerat());
	}


}