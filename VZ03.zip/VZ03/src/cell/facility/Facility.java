/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cell.facility;

import cell.Cell;
import indices.Indices;

/**Abstract Class Facility.
*
* @author Emil
*/

public abstract class Facility extends Cell {
  /** Attribut Ftype yang adalah type dari fasilitas.
   */

  protected int ftype;
  
  /** Constructor dari Facility.
   * Menghidupkan fasilitas
   *
   * @param ind Indices adalah alamat dimana fasilitas dihidupkan
   * @param type integer adalah kode dari fasilitas dimana 0=Road, 1=Park, 2=Restaurant
   * @param code character adalah suatu huruf untuk merepresentasikan fasilitas di layar.
   */
  
  public Facility(Indices ind, int type, char code) {
    super(ind, 1, code);
    ftype = type;
  }
  
  /** Mengembalikan nilai boolean apakah fasilitas adalah road.
   */
  
  public final boolean isRoad() {
    return (ftype == 0);
  }
  
  /** Mengembalikan nilai boolean apakah fasilitas adalah park.
   */
  
  public final boolean isPark() {
    return (ftype == 1);
  }
  
  /** Mengembalikan nilai boolean apakah fasilitas adalah restaurant.
   */
  
  public final boolean isRestaurant() {
    return (ftype == 2);
  }
}