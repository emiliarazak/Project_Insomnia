package cell.facility.park;
import static org.junit.Assert.*;
import org.junit.Test;

import indices.Indices;
/**
*
* @author Emil
*/ 
public class ParkTest {
	private Indices ind = new Indices(5,6);
	private Park p = new Park(ind);
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'P', p.render());
	}
	@Test
	public void testPark() {
		assertEquals("Constructor Park parameter 1 Error!", 5, p.getKoordinat().getAbsis());
		assertEquals("Constructor Park parameter 1 Error!", 6, p.getKoordinat().getOrdinat());
	}
	@Test
	public void testFacility() {
		assertEquals("Constructor Facility parameter 1 Error!", 5, p.getKoordinat().getAbsis());
		assertEquals("Constructor Facility parameter 1 Error!", 6, p.getKoordinat().getOrdinat());
		assertEquals("Constructor Facility parameter 2 Error!", true, p.isPark());
		assertEquals("Constructor Facility parameter 2 Error!", false, p.isRoad());
		assertEquals("Constructor Facility parameter 2 Error!", false, p.isRestaurant());
		assertEquals("Constructor Facility parameter 3 Error!", 'p', p.getCode());
	}
	@Test
	public void testIsRoad() {
		assertEquals("isRoad() Error!", false, p.isRoad());
	}
	@Test
	public void testIsPark() {
		assertEquals("isPark() Error!", true, p.isPark());
	}
	@Test
	public void testIsRestaurant() {
		assertEquals("IsRetaurant() Error!", false, p.isRestaurant());
	}
	@Test
	public void testCell() {
		assertEquals("Constructor Cell parameter 1 Error!", 5, p.getKoordinat().getAbsis());
		assertEquals("Constructor Cell parameter 1 Error!", 6, p.getKoordinat().getOrdinat());
		assertEquals("Constructor Cell parameter 2 Error!", true, p.isFacility());
		assertEquals("Constructor Cell parameter 2 Error!", false, p.isHabitat());
		assertEquals("Constructor Cell parameter 3 Error!", 'p', p.getCode());
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("getKoordinat() Error!", 5, p.getKoordinat().getAbsis());
		assertEquals("getKoordinat() Error!", 6, p.getKoordinat().getOrdinat());
	}
	@Test
	public void testIsHabitat() {
		assertEquals("isHabitat() Error!", false, p.isHabitat());
	}
	@Test
	public void testIsFacility() {
		assertEquals("isFacility() Error!", true, p.isFacility());
	}
	@Test
	public void testGetCode() {
		assertEquals("getCode() Error!", 'p', p.getCode());
	}

}