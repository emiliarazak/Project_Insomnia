package cell.facility.road;
import static org.junit.Assert.*;
/**
*
* @author Emil
*/
import org.junit.Test;

import indices.Indices;

public class RoadTest {
	private Indices ind = new Indices(1,4);
	private Road s = new Road(ind, 1);
	@Test
	public void testRender() {
		assertEquals("render() Error!", '+', s.render());
	}
	@Test
	public void testRoad() {
		assertEquals("Constructor Road parameter 1 Error!", 1, s.getKoordinat().getAbsis());
		assertEquals("Constructor Road parameter 1 Error!", 4, s.getKoordinat().getOrdinat());
	}
	@Test
	public void testFacility() {
		assertEquals("Constructor Facility parameter 1 Error!", 1, s.getKoordinat().getAbsis());
		assertEquals("Constructor Facility parameter 1 Error!", 4, s.getKoordinat().getOrdinat());
		assertEquals("Constructor Facility parameter 2 Error!", true, s.isRoad());
		assertEquals("Constructor Facility parameter 2 Error!", false, s.isRestaurant());
		assertEquals("Constructor Facility parameter 2 Error!", false, s.isPark());
		assertEquals("Constructor Facility parameter 3 Error!", 's', s.getCode());
	}
	@Test
	public void testIsRoad() {
		assertEquals("isRoad() Error!", true, s.isRoad());
	}
	@Test
	public void testIsPark() {
		assertEquals("isPark() Error!", false, s.isPark());
	}
	@Test
	public void testIsRestaurant() {
		assertEquals("isRestaurant() Error!", false, s.isRestaurant());
	}
	@Test
	public void testCell() {
		assertEquals("Constructor Cell parameter 1 Error!", 1, s.getKoordinat().getAbsis());
		assertEquals("Constructor Cell parameter 1 Error!", 4, s.getKoordinat().getOrdinat());
		assertEquals("Constructor Cell parameter 2 Error!", true, s.isFacility());
		assertEquals("Constructor Cell parameter 2 Error!", false, s.isHabitat());
		assertEquals("Constructor Cell parameter 3 Error!", 's', s.getCode());
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("getKoordinat() Error!", 1, s.getKoordinat().getAbsis());
		assertEquals("getKoordinat() Error!", 4, s.getKoordinat().getOrdinat());
	}
	@Test
	public void testIsHabitat() {
		assertEquals("isHabitat() Error!", false, s.isHabitat());
	}
	@Test
	public void testIsFacility() {
		assertEquals("isHabitat() Error!", true, s.isFacility());
	}
	@Test
	public void testGetCode() {
		assertEquals("getCode() Error!", 's', s.getCode());
	}
}