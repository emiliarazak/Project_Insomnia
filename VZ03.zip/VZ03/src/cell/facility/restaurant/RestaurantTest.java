package cell.facility.restaurant;
import static org.junit.Assert.*;
import org.junit.Test;

import indices.Indices;
/**
*
* @author Emil
*/
public class RestaurantTest {
	private Indices ind = new Indices(3,4);
	private Restaurant r = new Restaurant(ind);
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'R', r.render());
	}
	@Test
	public void testRestaurant() {
		assertEquals("Constructor Restaurant parameter 1 Error!", 3, r.getKoordinat().getAbsis());
		assertEquals("Constructor Restaurant parameter 1 Error!", 4, r.getKoordinat().getOrdinat());
	}
	@Test
	public void testFacility() {
		assertEquals("Constructor Facility parameter 1 Error!", 3, r.getKoordinat().getAbsis());
		assertEquals("Constructor Facility parameter 1 Error!", 4, r.getKoordinat().getOrdinat());
		assertEquals("Constructor Facility parameter 2 Error!", true, r.isRestaurant());
		assertEquals("Constructor Facility parameter 2 Error!", false, r.isRoad());
		assertEquals("Constructor Facility parameter 2 Error!", false, r.isPark());
		assertEquals("Constructor Facility parameter 3 Error!", 'r', r.getCode());
	}
	@Test
	public void testIsRoad() {
		assertEquals("isRoad() Error!", false, r.isRoad());
	}
	@Test
	public void testIsPark() {
		assertEquals("isPark() Error!", false, r.isPark());
	}
	@Test
	public void testIsRestaurant() {
		assertEquals("isPark() Error!", true, r.isRestaurant());
	}
	@Test
	public void testCell() {
		assertEquals("Constructor Cell parameter 1 Error!", 3, r.getKoordinat().getAbsis());
		assertEquals("Constructor Cell parameter 1 Error!", 4, r.getKoordinat().getOrdinat());
		assertEquals("Constructor Cell parameter 2 Error!", true, r.isFacility());
		assertEquals("Constructor Cell parameter 2 Error!", false, r.isHabitat());
		assertEquals("Constructor Cell parameter 3 Error!", 'r', r.getCode());
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("getKoordinat() Error!", 3, r.getKoordinat().getAbsis());
		assertEquals("getKoordinat() Error!", 4, r.getKoordinat().getOrdinat());
	}
	@Test
	public void testIsHabitat() {
		assertEquals("isHabitat() Error!", false, r.isHabitat());
	}
	@Test
	public void testIsFacility() {
		assertEquals("isFacility() Error!", true, r.isFacility());
	}
	@Test
	public void testGetCode() {
		assertEquals("getCode() Error!", 'r', r.getCode());
	}

}