/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cell.facility.restaurant;

import cell.facility.Facility;
import indices.Indices;

/** Real Class Restaurant.
*
* @author Emil
*/

public class Restaurant extends Facility {

  /** Constructor dari Restaurant.
   * Menghidupkan fasilitas restauran
   *
   * @param ind Indices adalah alamat dimana fasilitas dihidupkan
   */

  public Restaurant(Indices ind) {
    super(ind, 2, 'r');
  }
  
  /** Mengembalikan nilai character kode dari objek Restaurant.
   * Character ini nantinya yang siap di Print ke layar
   */
  
  public char render() {
    return 'R';
  }
}