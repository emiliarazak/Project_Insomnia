/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cell;

import indices.Indices;
import renderable.Renderable;

/** Abstract Class Cell.
 *
 * @author Emil
 */

public abstract class Cell implements Renderable {

  /** Attribut Koordinat yang adalah Indices letak cell.
   */

  protected Indices koordinat;
  
  /** Attribut type yang adalah type dari Cell.
   */

  protected int type;
  
  /** Attribut code yang adalah code dari Cell.
   */
  
  protected char code;
  
  /** Constructor dari Cell.
   * Menghidupkan cell
   *
   * @param ind Indices adalah alamat dimana cell dihidupkan
   * @param t integer adalah kode dari cell dimana 0=Habitat, 1=Facility
   * @param c character adalah suatu huruf untuk merepresentasikan cell di layar.
   */
  
  public Cell(Indices ind, int t, char c) {
    koordinat = ind;
    type = t;
    code = c;
  }
  
  @Override
  /** Mengembalikan nilai character render dari objek Cell
   * Character ini nantinya yang siap di Print ke layar
   */
  
  public char render() {
    return '.';
  }
  
  /** Mengembalikan nilai Indices dimana cell berada.
   */
  
  public Indices getKoordinat() {
    return koordinat;
  }
  
  /** Mengembalikan nilai boolean apakah cell adalah habitat.
   */
  
  public final boolean isHabitat() {
    return (type == 0);
  }
  
  /** Mengembalikan nilai boolean apakah cell adalah fasilitas.
   */
  
  public final boolean isFacility() {
    return (type == 1);
  }
  
  /** Mengembalikan nilai char code yang adalah atribut cell.
   */
  
  public final char getCode() {
    return code;
  }
}