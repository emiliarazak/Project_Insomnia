package cell.habitat.waterhabitat;
import static org.junit.Assert.*;

import org.junit.Test;

import indices.Indices;
/**
*
* @author Emil
*/
public class WaterHabitatTest {
	private Indices ind = new Indices(2,5);
	private WaterHabitat w = new WaterHabitat(ind);
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'w', w.render());
	}
	@Test
	public void testWaterHabitat() {
		assertEquals("Constructor WaterHabitat parameter 1 Error!", 2, w.getKoordinat().getAbsis());
		assertEquals("Constructor WaterHabitat parameter 1 Error!", 5, w.getKoordinat().getOrdinat());
	}
	@Test
	public void testHabitat() {
		assertEquals("Constructor Habitat parameter 1 Error!", 2, w.getKoordinat().getAbsis());
		assertEquals("Constructor Habitat parameter 1 Error!", 5, w.getKoordinat().getOrdinat());
		assertEquals("Constructor Habitat parameter 2 Error!", true, w.isWater());
		assertEquals("Constructor Habitat parameter 2 Error!", false, w.isLand());
		assertEquals("Constructor Habitat parameter 2 Error!", false, w.isAir());
		assertEquals("Constructor Habitat parameter 2 Error!", 'w', w.getCode());
	}
	@Test
	public void testIsLand() {
		assertEquals("isLand() Error!", false, w.isLand());
	}
	@Test
	public void testIsWater() {
		assertEquals("isWater() Error!", true, w.isWater());
	}
	@Test
	public void testIsAir() {
		assertEquals("isAir() Error!", false, w.isAir());
	}
	@Test
	public void testCell() {
		assertEquals("Constructor Cell parameter 1 Error!", 2, w.getKoordinat().getAbsis());
		assertEquals("Constructor Cell parameter 1 Error!", 5, w.getKoordinat().getOrdinat());
		assertEquals("Constructor Cell parameter 2 Error!", true, w.isHabitat());
		assertEquals("Constructor Cell parameter 2 Error!", false, w.isFacility());
		assertEquals("Constructor Cell parameter 3 Error!", 'w', w.getCode());
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("getKoordinat() Error!", 2, w.getKoordinat().getAbsis());
		assertEquals("getKoordinat() Error!", 5, w.getKoordinat().getOrdinat());
	}
	@Test
	public void testIsHabitat() {
		assertEquals("isHabitat() Error!", true, w.isHabitat());
	}
	@Test
	public void testIsFacility() {
		assertEquals("isFacility() Error!", false, w.isFacility());
	}
	@Test
	public void testGetCode() {
		assertEquals("getCode() Error!", 'w', w.getCode());
	}
}