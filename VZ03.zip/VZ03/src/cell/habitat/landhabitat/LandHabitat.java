/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cell.habitat.landhabitat;

import cell.habitat.Habitat;
import indices.Indices;

/** Real Class LandHabitat. 
*
* @author Emil
*/

public class LandHabitat extends Habitat {

  /** Constructor dari Land Habitat.
   * Menghidupkan habitat darat
   *
   * @param ind Indices adalah alamat dimana habitat dihidupkan
   */

  public LandHabitat(Indices ind) {
    super(ind, 0, 'l');
  }
  
  /** Mengembalikan nilai character kode dari objek Land Habitat.
   * Character ini nantinya yang siap di Print ke layar
   */
  
  public char render() {
    return 'l';
  }
}