package cell.habitat.landhabitat;
import static org.junit.Assert.*;
import org.junit.Test;
import indices.Indices;
/**
*
* @author Emil
*/
public class LandHabitatTest {
	private Indices ind = new Indices(3,6);
	private LandHabitat l = new LandHabitat(ind);
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'l', l.render());
	}
	@Test
	public void testLandHabitat() {
		assertEquals("Constructor LandHabitat parameter 1 Error!", 3, l.getKoordinat().getAbsis());
		assertEquals("Constructor LandHabitat parameter 1 Error!", 6, l.getKoordinat().getOrdinat());
	}
	@Test
	public void testHabitat() {
		assertEquals("Constructor Habitat parameter 1 Error!", 3, l.getKoordinat().getAbsis());
		assertEquals("Constructor Habitat parameter 1 Error!", 6, l.getKoordinat().getOrdinat());
		assertEquals("Constructor Habitat parameter 2 Error!", true, l.isLand());
		assertEquals("Constructor Habitat parameter 2 Error!", false, l.isWater());
		assertEquals("Constructor Habitat parameter 2 Error!", false, l.isAir());
		assertEquals("Constructor Habitat parameter 3 Error!", 'l', l.getCode());
	}
	@Test
	public void testIsLand() {
		assertEquals("isLand() Error!", true, l.isLand());
	}
	@Test
	public void testIsWater() {
		assertEquals("isWater() Error!", false, l.isWater());
	}
	@Test
	public void testIsAir() {
		assertEquals("isAir() Error!", false, l.isAir());
	}
	@Test
	public void testCell() {
		assertEquals("Constructor Cell parameter 1 Error!", 3, l.getKoordinat().getAbsis());
		assertEquals("Constructor Cell parameter 1 Error!", 6, l.getKoordinat().getOrdinat());
		assertEquals("Constructor Cell parameter 2 Error!", true, l.isHabitat());
		assertEquals("Constructor Cell parameter 2 Error!", false, l.isFacility());
		assertEquals("Constructor Cell parameter 3 Error!", 'l', l.getCode());
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("getKoordinat() Error!", 3, l.getKoordinat().getAbsis());
		assertEquals("getKoordinat() Error!", 6, l.getKoordinat().getOrdinat());
	}
	@Test
	public void testIsHabitat() {
		assertEquals("isHabitat() Error!", true, l.isHabitat());
	}
	@Test
	public void testIsFacility() {
		assertEquals("isFacility() Error!", false, l.isFacility());
	}

	@Test
	public void testGetCode() {
		assertEquals("getCode() Error!", 'l', l.getCode());
	}
}