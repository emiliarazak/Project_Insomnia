package cell.habitat.airhabitat;
import static org.junit.Assert.*;
import org.junit.Test;

import indices.Indices;
/**
*
* @author Emil
*/
public class AirHabitatTest {
	private Indices ind = new Indices(2,4);
	private AirHabitat a = new AirHabitat(ind);
	@Test
	public void testRender() {
		assertEquals("render() Error!", 'a', a.render());
	}
	@Test
	public void testAirHabitat() {
		assertEquals("Constructor AirHabitat parameter 1 Error!", 2, a.getKoordinat().getAbsis());
		assertEquals("Constructor AirHabitat parameter 1 Error!", 4, a.getKoordinat().getOrdinat());
	}
	@Test
	public void testHabitat() {
		assertEquals("Constructor Habitat parameter 1 Error!", 2, a.getKoordinat().getAbsis());
		assertEquals("Constructor Habitat parameter 1 Error!", 4, a.getKoordinat().getOrdinat());
		assertEquals("Constructor Habitat parameter 2 Error!", true, a.isAir());
		assertEquals("Constructor Habitat parameter 2 Error!", false, a.isLand());
		assertEquals("Constructor Habitat parameter 2 Error!", false, a.isWater());
		assertEquals("Constructor Habitat parameter 3 Error!", 'a', a.getCode());
	}
	@Test
	public void testIsLand() {
		assertEquals("isLand() Error!", false, a.isLand());
	}
	@Test
	public void testIsWater() {
		assertEquals("isWater() Error!", false, a.isWater());
	}
	@Test
	public void testIsAir() {
		assertEquals("isAir() Error!", true, a.isAir());
	}
	@Test
	public void testCell() {
		assertEquals("Constructor Cell parameter 1 Error!", 2, a.getKoordinat().getAbsis());
		assertEquals("Constructor Cell parameter 1 Error!", 4, a.getKoordinat().getOrdinat());
		assertEquals("Constructor Cell parameter 2 Error!", true, a.isHabitat());
		assertEquals("Constructor Cell parameter 2 Error!", false, a.isFacility());
		assertEquals("Constructor Cell parameter 3 Error!", 'a', a.getCode());
	}
	@Test
	public void testGetKoordinat() {
		assertEquals("getKoordinat() Error!", 2, a.getKoordinat().getAbsis());
		assertEquals("getKoordinat() Error!", 4, a.getKoordinat().getOrdinat());
	}
	@Test
	public void testIsHabitat() {
		assertEquals("isHabitat() Error!", true, a.isHabitat());
	}
	@Test
	public void testIsFacility() {
		assertEquals("isFacility() Error!", false, a.isFacility());
	}
	@Test
	public void testGetCode() {
		assertEquals("getCode() Error!", 'a', a.getCode());
	}
}