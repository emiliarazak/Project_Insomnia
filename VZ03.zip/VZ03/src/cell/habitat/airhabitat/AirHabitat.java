/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cell.habitat.airhabitat;

import cell.habitat.Habitat;
import indices.Indices;

/** Real Class AirHabitat.
*
* @author Emil
*/

public class AirHabitat extends Habitat {
  /** Constructor dari Air Habitat.
   * Menghidupkan habitat udara
   *
   * @param ind Indices adalah alamat dimana habitat dihidupkan
   */

  public AirHabitat(Indices ind) {
    super(ind, 2, 'a');
  }
  
  /** Mengembalikan nilai character kode dari objek Air Habitat.
   * Character ini nantinya yang siap di Print ke layar
   */
  
  public char render() {
    return 'a';
  }
}