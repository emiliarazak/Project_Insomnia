package character;
import point.Point;
import draw.Draw;
import control.Keys;
public class Player extends Character implements Draw {
	
	public Player(Point coordinate) {
		super(5,coordinate);
	}
	
	public void draw() {
		System.out.println('@');
	}
	
	public void Move(){
		if(Keys.isPressed(Keys.UP)){
			super.setPosition(coordinate.getAbsis(), coordinate.getOrdinat()-1);
			draw();
		}
		else if(Keys.isPressed(Keys.LEFT)){
			super.setPosition(coordinate.getAbsis()-1, coordinate.getOrdinat());
			draw();
		}
		else if(Keys.isPressed(Keys.DOWN)){
			super.setPosition(coordinate.getAbsis(), coordinate.getOrdinat()+1);
			draw();
		}
		else if(Keys.isPressed(Keys.RIGHT)){
			super.setPosition(coordinate.getAbsis()+1, coordinate.getOrdinat());
			draw();
		}
	}
	
	public void Attack() {
	
	}
}
