package character;
import point.Point;
public class Character {
	  	private final int max_life;
	    protected int life;
	    protected Point coordinate;
	    
	    public Character(int max_life, Point coordinate) {
	        this.max_life=max_life;
	        this.coordinate=coordinate;
	        life=max_life;
	    }
	    
	    public int getLife(){
	        return life;
	    }
	    
	    public void setLife(int life) {
	    	if (life>max_life){
	    		this.life=max_life;
	    	}
	    	else{
	    		 this.life=life;
	    	}
	    }
	    
	    public boolean isDead(){
	    	return (life==0);
	    }
	    
	    public void setPosition(int x, int y){
	    	coordinate.setAbsis(x);
	    	coordinate.setOrdinat(y);
	    }
	    
	    public Point getPosition(){
	    	return coordinate;
	    }
	    }
	    public void Move() {
	    	
	    }
	    public void Attack() {
	    	
	    }
	}

