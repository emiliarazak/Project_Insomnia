package character;

import point.Point;

public class EnemyBoss extends Character {
	public EnemyBoss(Point coordinate) {
		super(15, coordinate);
	}
	
	public int getLife(){
        return life;
    }
	
    public void setLife(int life) {
        this.life=life;
    }
    public boolean isDead() {
    	return (life==0);
    }
    public void Move() {
    	
    }
    
    public void Attack() {
    	
    }
}
