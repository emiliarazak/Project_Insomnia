package character;

import point.Point;
import draw.Draw;
public class Enemy1 extends Character implements Draw{
	public Enemy1(Point coordinate) {
		super(1, coordinate);
	}
	
	public void draw(){
		
	}
    public void Move() {
    	
    }
    
    public void Attack() {
    	
    }
}
