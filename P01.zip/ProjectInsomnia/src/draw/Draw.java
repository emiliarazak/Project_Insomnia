package draw;

public interface Draw {
	
	void draw();
}
