package cell;
import point.Point;
public class Portal extends Cell{
	public Portal(Point coordinate) {
		super('p', coordinate);
	}
}
