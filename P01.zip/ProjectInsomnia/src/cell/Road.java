package cell;
import point.Point;
public class Road extends Cell {
	public Road(Point coordinate){
		super('r', coordinate);
	}
}
