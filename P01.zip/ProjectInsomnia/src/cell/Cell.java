package cell;
import point.Point;
public class Cell {
	 private Point coordinate;
	    //type='r' adalah road,type='o' adalah obstacle, type='p' adalah portal
	    private final char type;
	    
	    public Cell(char type, Point coordinate) {
	        this.type=type;
	        this.coordinate=coordinate;
	    }
	    
	    public Point getCoordinate() {
	        return coordinate;
	    }
	    
	    public void setCoordinate(Point coordinate) {
	        this.coordinate=coordinate;
	    }
	    
	    public char getType() {
	        return type;
	}
}
