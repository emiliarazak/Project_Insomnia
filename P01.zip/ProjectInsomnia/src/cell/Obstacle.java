package cell;
import point.Point;
public class Obstacle extends Cell{
	public Obstacle(Point coordinate) {
		super('o', coordinate);
	}
}
